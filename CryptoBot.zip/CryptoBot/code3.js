gdjs.SafePromptCode = {};
gdjs.SafePromptCode.GDBackgroundObjects1= [];
gdjs.SafePromptCode.GDBackgroundObjects2= [];
gdjs.SafePromptCode.GDBackgroundObjects3= [];
gdjs.SafePromptCode.GDCodePromptObjects1= [];
gdjs.SafePromptCode.GDCodePromptObjects2= [];
gdjs.SafePromptCode.GDCodePromptObjects3= [];
gdjs.SafePromptCode.GDInstructionsObjects1= [];
gdjs.SafePromptCode.GDInstructionsObjects2= [];
gdjs.SafePromptCode.GDInstructionsObjects3= [];
gdjs.SafePromptCode.GDwhileObjects1= [];
gdjs.SafePromptCode.GDwhileObjects2= [];
gdjs.SafePromptCode.GDwhileObjects3= [];
gdjs.SafePromptCode.GDifObjects1= [];
gdjs.SafePromptCode.GDifObjects2= [];
gdjs.SafePromptCode.GDifObjects3= [];
gdjs.SafePromptCode.GDbodyObjects1= [];
gdjs.SafePromptCode.GDbodyObjects2= [];
gdjs.SafePromptCode.GDbodyObjects3= [];
gdjs.SafePromptCode.GDpieceClicksObjects1= [];
gdjs.SafePromptCode.GDpieceClicksObjects2= [];
gdjs.SafePromptCode.GDpieceClicksObjects3= [];
gdjs.SafePromptCode.GDpieceDirectionObjects1= [];
gdjs.SafePromptCode.GDpieceDirectionObjects2= [];
gdjs.SafePromptCode.GDpieceDirectionObjects3= [];
gdjs.SafePromptCode.GDpieceSoundObjects1= [];
gdjs.SafePromptCode.GDpieceSoundObjects2= [];
gdjs.SafePromptCode.GDpieceSoundObjects3= [];
gdjs.SafePromptCode.GDpieceChangeObjects1= [];
gdjs.SafePromptCode.GDpieceChangeObjects2= [];
gdjs.SafePromptCode.GDpieceChangeObjects3= [];
gdjs.SafePromptCode.GDbox1Objects1= [];
gdjs.SafePromptCode.GDbox1Objects2= [];
gdjs.SafePromptCode.GDbox1Objects3= [];
gdjs.SafePromptCode.GDbox2Objects1= [];
gdjs.SafePromptCode.GDbox2Objects2= [];
gdjs.SafePromptCode.GDbox2Objects3= [];
gdjs.SafePromptCode.GDbox3Objects1= [];
gdjs.SafePromptCode.GDbox3Objects2= [];
gdjs.SafePromptCode.GDbox3Objects3= [];
gdjs.SafePromptCode.GDbox4Objects1= [];
gdjs.SafePromptCode.GDbox4Objects2= [];
gdjs.SafePromptCode.GDbox4Objects3= [];
gdjs.SafePromptCode.GDSuccessObjects1= [];
gdjs.SafePromptCode.GDSuccessObjects2= [];
gdjs.SafePromptCode.GDSuccessObjects3= [];
gdjs.SafePromptCode.GDDialogueBoxObjects1= [];
gdjs.SafePromptCode.GDDialogueBoxObjects2= [];
gdjs.SafePromptCode.GDDialogueBoxObjects3= [];
gdjs.SafePromptCode.GDhelpDialogueObjects1= [];
gdjs.SafePromptCode.GDhelpDialogueObjects2= [];
gdjs.SafePromptCode.GDhelpDialogueObjects3= [];
gdjs.SafePromptCode.GDexitButtonObjects1= [];
gdjs.SafePromptCode.GDexitButtonObjects2= [];
gdjs.SafePromptCode.GDexitButtonObjects3= [];
gdjs.SafePromptCode.GDhelpButtonObjects1= [];
gdjs.SafePromptCode.GDhelpButtonObjects2= [];
gdjs.SafePromptCode.GDhelpButtonObjects3= [];
gdjs.SafePromptCode.GDexitDialogueObjects1= [];
gdjs.SafePromptCode.GDexitDialogueObjects2= [];
gdjs.SafePromptCode.GDexitDialogueObjects3= [];
gdjs.SafePromptCode.GDYESObjects1= [];
gdjs.SafePromptCode.GDYESObjects2= [];
gdjs.SafePromptCode.GDYESObjects3= [];
gdjs.SafePromptCode.GDNOObjects1= [];
gdjs.SafePromptCode.GDNOObjects2= [];
gdjs.SafePromptCode.GDNOObjects3= [];
gdjs.SafePromptCode.GDCONFIRMObjects1= [];
gdjs.SafePromptCode.GDCONFIRMObjects2= [];
gdjs.SafePromptCode.GDCONFIRMObjects3= [];
gdjs.SafePromptCode.GDDialogueObjects1= [];
gdjs.SafePromptCode.GDDialogueObjects2= [];
gdjs.SafePromptCode.GDDialogueObjects3= [];
gdjs.SafePromptCode.GDNextObjects1= [];
gdjs.SafePromptCode.GDNextObjects2= [];
gdjs.SafePromptCode.GDNextObjects3= [];
gdjs.SafePromptCode.GDsuccessDialogueObjects1= [];
gdjs.SafePromptCode.GDsuccessDialogueObjects2= [];
gdjs.SafePromptCode.GDsuccessDialogueObjects3= [];
gdjs.SafePromptCode.GDTimerSecondsObjects1= [];
gdjs.SafePromptCode.GDTimerSecondsObjects2= [];
gdjs.SafePromptCode.GDTimerSecondsObjects3= [];
gdjs.SafePromptCode.GDTimerMinutesObjects1= [];
gdjs.SafePromptCode.GDTimerMinutesObjects2= [];
gdjs.SafePromptCode.GDTimerMinutesObjects3= [];

gdjs.SafePromptCode.conditionTrue_0 = {val:false};
gdjs.SafePromptCode.condition0IsTrue_0 = {val:false};
gdjs.SafePromptCode.condition1IsTrue_0 = {val:false};
gdjs.SafePromptCode.condition2IsTrue_0 = {val:false};
gdjs.SafePromptCode.condition3IsTrue_0 = {val:false};
gdjs.SafePromptCode.condition4IsTrue_0 = {val:false};


gdjs.SafePromptCode.mapOfGDgdjs_46SafePromptCode_46GDDialogueBoxObjects1Objects = Hashtable.newFrom({"DialogueBox": gdjs.SafePromptCode.GDDialogueBoxObjects1});gdjs.SafePromptCode.mapOfGDgdjs_46SafePromptCode_46GDNextObjects1Objects = Hashtable.newFrom({"Next": gdjs.SafePromptCode.GDNextObjects1});gdjs.SafePromptCode.mapOfGDgdjs_46SafePromptCode_46GDNextObjects1Objects = Hashtable.newFrom({"Next": gdjs.SafePromptCode.GDNextObjects1});gdjs.SafePromptCode.eventsList0 = function(runtimeScene) {

{


gdjs.SafePromptCode.condition0IsTrue_0.val = false;
{
gdjs.SafePromptCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if (gdjs.SafePromptCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("CodePrompt"), gdjs.SafePromptCode.GDCodePromptObjects1);
gdjs.copyArray(runtimeScene.getObjects("Dialogue"), gdjs.SafePromptCode.GDDialogueObjects1);
gdjs.copyArray(runtimeScene.getObjects("DialogueBox"), gdjs.SafePromptCode.GDDialogueBoxObjects1);
gdjs.copyArray(runtimeScene.getObjects("Instructions"), gdjs.SafePromptCode.GDInstructionsObjects1);
/* Reuse gdjs.SafePromptCode.GDNextObjects1 */
gdjs.copyArray(runtimeScene.getObjects("body"), gdjs.SafePromptCode.GDbodyObjects1);
gdjs.copyArray(runtimeScene.getObjects("box1"), gdjs.SafePromptCode.GDbox1Objects1);
gdjs.copyArray(runtimeScene.getObjects("box2"), gdjs.SafePromptCode.GDbox2Objects1);
gdjs.copyArray(runtimeScene.getObjects("box3"), gdjs.SafePromptCode.GDbox3Objects1);
gdjs.copyArray(runtimeScene.getObjects("box4"), gdjs.SafePromptCode.GDbox4Objects1);
gdjs.copyArray(runtimeScene.getObjects("exitButton"), gdjs.SafePromptCode.GDexitButtonObjects1);
gdjs.copyArray(runtimeScene.getObjects("helpButton"), gdjs.SafePromptCode.GDhelpButtonObjects1);
gdjs.copyArray(runtimeScene.getObjects("if"), gdjs.SafePromptCode.GDifObjects1);
gdjs.copyArray(runtimeScene.getObjects("pieceChange"), gdjs.SafePromptCode.GDpieceChangeObjects1);
gdjs.copyArray(runtimeScene.getObjects("pieceClicks"), gdjs.SafePromptCode.GDpieceClicksObjects1);
gdjs.copyArray(runtimeScene.getObjects("pieceDirection"), gdjs.SafePromptCode.GDpieceDirectionObjects1);
gdjs.copyArray(runtimeScene.getObjects("pieceSound"), gdjs.SafePromptCode.GDpieceSoundObjects1);
gdjs.copyArray(runtimeScene.getObjects("while"), gdjs.SafePromptCode.GDwhileObjects1);
{for(var i = 0, len = gdjs.SafePromptCode.GDDialogueBoxObjects1.length ;i < len;++i) {
    gdjs.SafePromptCode.GDDialogueBoxObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.SafePromptCode.GDNextObjects1.length ;i < len;++i) {
    gdjs.SafePromptCode.GDNextObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.SafePromptCode.GDDialogueObjects1.length ;i < len;++i) {
    gdjs.SafePromptCode.GDDialogueObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.SafePromptCode.GDCodePromptObjects1.length ;i < len;++i) {
    gdjs.SafePromptCode.GDCodePromptObjects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.SafePromptCode.GDInstructionsObjects1.length ;i < len;++i) {
    gdjs.SafePromptCode.GDInstructionsObjects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.SafePromptCode.GDwhileObjects1.length ;i < len;++i) {
    gdjs.SafePromptCode.GDwhileObjects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.SafePromptCode.GDifObjects1.length ;i < len;++i) {
    gdjs.SafePromptCode.GDifObjects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.SafePromptCode.GDbodyObjects1.length ;i < len;++i) {
    gdjs.SafePromptCode.GDbodyObjects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.SafePromptCode.GDpieceClicksObjects1.length ;i < len;++i) {
    gdjs.SafePromptCode.GDpieceClicksObjects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.SafePromptCode.GDpieceDirectionObjects1.length ;i < len;++i) {
    gdjs.SafePromptCode.GDpieceDirectionObjects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.SafePromptCode.GDpieceSoundObjects1.length ;i < len;++i) {
    gdjs.SafePromptCode.GDpieceSoundObjects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.SafePromptCode.GDpieceChangeObjects1.length ;i < len;++i) {
    gdjs.SafePromptCode.GDpieceChangeObjects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.SafePromptCode.GDbox1Objects1.length ;i < len;++i) {
    gdjs.SafePromptCode.GDbox1Objects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.SafePromptCode.GDbox2Objects1.length ;i < len;++i) {
    gdjs.SafePromptCode.GDbox2Objects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.SafePromptCode.GDbox3Objects1.length ;i < len;++i) {
    gdjs.SafePromptCode.GDbox3Objects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.SafePromptCode.GDbox4Objects1.length ;i < len;++i) {
    gdjs.SafePromptCode.GDbox4Objects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.SafePromptCode.GDhelpButtonObjects1.length ;i < len;++i) {
    gdjs.SafePromptCode.GDhelpButtonObjects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.SafePromptCode.GDexitButtonObjects1.length ;i < len;++i) {
    gdjs.SafePromptCode.GDexitButtonObjects1[i].hide(false);
}
}}

}


};gdjs.SafePromptCode.mapOfGDgdjs_46SafePromptCode_46GDNextObjects1Objects = Hashtable.newFrom({"Next": gdjs.SafePromptCode.GDNextObjects1});gdjs.SafePromptCode.mapOfGDgdjs_46SafePromptCode_46GDpieceClicksObjects1Objects = Hashtable.newFrom({"pieceClicks": gdjs.SafePromptCode.GDpieceClicksObjects1});gdjs.SafePromptCode.mapOfGDgdjs_46SafePromptCode_46GDbox1Objects1Objects = Hashtable.newFrom({"box1": gdjs.SafePromptCode.GDbox1Objects1});gdjs.SafePromptCode.mapOfGDgdjs_46SafePromptCode_46GDpieceDirectionObjects1Objects = Hashtable.newFrom({"pieceDirection": gdjs.SafePromptCode.GDpieceDirectionObjects1});gdjs.SafePromptCode.mapOfGDgdjs_46SafePromptCode_46GDbox2Objects1Objects = Hashtable.newFrom({"box2": gdjs.SafePromptCode.GDbox2Objects1});gdjs.SafePromptCode.mapOfGDgdjs_46SafePromptCode_46GDpieceSoundObjects1Objects = Hashtable.newFrom({"pieceSound": gdjs.SafePromptCode.GDpieceSoundObjects1});gdjs.SafePromptCode.mapOfGDgdjs_46SafePromptCode_46GDbox3Objects1Objects = Hashtable.newFrom({"box3": gdjs.SafePromptCode.GDbox3Objects1});gdjs.SafePromptCode.mapOfGDgdjs_46SafePromptCode_46GDpieceChangeObjects1Objects = Hashtable.newFrom({"pieceChange": gdjs.SafePromptCode.GDpieceChangeObjects1});gdjs.SafePromptCode.mapOfGDgdjs_46SafePromptCode_46GDbox4Objects1Objects = Hashtable.newFrom({"box4": gdjs.SafePromptCode.GDbox4Objects1});gdjs.SafePromptCode.mapOfGDgdjs_46SafePromptCode_46GDDialogueBoxObjects1Objects = Hashtable.newFrom({"DialogueBox": gdjs.SafePromptCode.GDDialogueBoxObjects1});gdjs.SafePromptCode.mapOfGDgdjs_46SafePromptCode_46GDCONFIRMObjects1Objects = Hashtable.newFrom({"CONFIRM": gdjs.SafePromptCode.GDCONFIRMObjects1});gdjs.SafePromptCode.eventsList1 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("box1"), gdjs.SafePromptCode.GDbox1Objects1);
gdjs.copyArray(runtimeScene.getObjects("box2"), gdjs.SafePromptCode.GDbox2Objects1);
gdjs.copyArray(runtimeScene.getObjects("box3"), gdjs.SafePromptCode.GDbox3Objects1);
gdjs.copyArray(runtimeScene.getObjects("box4"), gdjs.SafePromptCode.GDbox4Objects1);
gdjs.copyArray(runtimeScene.getObjects("pieceChange"), gdjs.SafePromptCode.GDpieceChangeObjects1);
gdjs.copyArray(runtimeScene.getObjects("pieceClicks"), gdjs.SafePromptCode.GDpieceClicksObjects1);
gdjs.copyArray(runtimeScene.getObjects("pieceDirection"), gdjs.SafePromptCode.GDpieceDirectionObjects1);
gdjs.copyArray(runtimeScene.getObjects("pieceSound"), gdjs.SafePromptCode.GDpieceSoundObjects1);

gdjs.SafePromptCode.condition0IsTrue_0.val = false;
gdjs.SafePromptCode.condition1IsTrue_0.val = false;
gdjs.SafePromptCode.condition2IsTrue_0.val = false;
gdjs.SafePromptCode.condition3IsTrue_0.val = false;
{
gdjs.SafePromptCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.SafePromptCode.mapOfGDgdjs_46SafePromptCode_46GDpieceClicksObjects1Objects, gdjs.SafePromptCode.mapOfGDgdjs_46SafePromptCode_46GDbox1Objects1Objects, false, runtimeScene, true);
}if ( gdjs.SafePromptCode.condition0IsTrue_0.val ) {
{
gdjs.SafePromptCode.condition1IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.SafePromptCode.mapOfGDgdjs_46SafePromptCode_46GDpieceDirectionObjects1Objects, gdjs.SafePromptCode.mapOfGDgdjs_46SafePromptCode_46GDbox2Objects1Objects, false, runtimeScene, true);
}if ( gdjs.SafePromptCode.condition1IsTrue_0.val ) {
{
gdjs.SafePromptCode.condition2IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.SafePromptCode.mapOfGDgdjs_46SafePromptCode_46GDpieceSoundObjects1Objects, gdjs.SafePromptCode.mapOfGDgdjs_46SafePromptCode_46GDbox3Objects1Objects, false, runtimeScene, true);
}if ( gdjs.SafePromptCode.condition2IsTrue_0.val ) {
{
gdjs.SafePromptCode.condition3IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.SafePromptCode.mapOfGDgdjs_46SafePromptCode_46GDpieceChangeObjects1Objects, gdjs.SafePromptCode.mapOfGDgdjs_46SafePromptCode_46GDbox4Objects1Objects, false, runtimeScene, true);
}}
}
}
if (gdjs.SafePromptCode.condition3IsTrue_0.val) {
/* Reuse gdjs.SafePromptCode.GDsuccessDialogueObjects1 */
gdjs.SafePromptCode.GDCONFIRMObjects1.length = 0;

gdjs.SafePromptCode.GDDialogueBoxObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.SafePromptCode.mapOfGDgdjs_46SafePromptCode_46GDDialogueBoxObjects1Objects, 60, 350, "");
}{for(var i = 0, len = gdjs.SafePromptCode.GDDialogueBoxObjects1.length ;i < len;++i) {
    gdjs.SafePromptCode.GDDialogueBoxObjects1[i].setScale(gdjs.SafePromptCode.GDDialogueBoxObjects1[i].getScale() / (2));
}
}{for(var i = 0, len = gdjs.SafePromptCode.GDDialogueBoxObjects1.length ;i < len;++i) {
    gdjs.SafePromptCode.GDDialogueBoxObjects1[i].setOpacity(215);
}
}{for(var i = 0, len = gdjs.SafePromptCode.GDDialogueBoxObjects1.length ;i < len;++i) {
    gdjs.SafePromptCode.GDDialogueBoxObjects1[i].setZOrder(900);
}
}{for(var i = 0, len = gdjs.SafePromptCode.GDsuccessDialogueObjects1.length ;i < len;++i) {
    gdjs.SafePromptCode.GDsuccessDialogueObjects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.SafePromptCode.GDsuccessDialogueObjects1.length ;i < len;++i) {
    gdjs.SafePromptCode.GDsuccessDialogueObjects1[i].setZOrder(910);
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.SafePromptCode.mapOfGDgdjs_46SafePromptCode_46GDCONFIRMObjects1Objects, 400, 630, "");
}{for(var i = 0, len = gdjs.SafePromptCode.GDCONFIRMObjects1.length ;i < len;++i) {
    gdjs.SafePromptCode.GDCONFIRMObjects1[i].setZOrder(920);
}
}}

}


};gdjs.SafePromptCode.mapOfGDgdjs_46SafePromptCode_46GDCONFIRMObjects1Objects = Hashtable.newFrom({"CONFIRM": gdjs.SafePromptCode.GDCONFIRMObjects1});gdjs.SafePromptCode.eventsList2 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("helpDialogue"), gdjs.SafePromptCode.GDhelpDialogueObjects1);

gdjs.SafePromptCode.condition0IsTrue_0.val = false;
gdjs.SafePromptCode.condition1IsTrue_0.val = false;
{
gdjs.SafePromptCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if ( gdjs.SafePromptCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.SafePromptCode.GDhelpDialogueObjects1.length;i<l;++i) {
    if ( !(gdjs.SafePromptCode.GDhelpDialogueObjects1[i].isVisible()) ) {
        gdjs.SafePromptCode.condition1IsTrue_0.val = true;
        gdjs.SafePromptCode.GDhelpDialogueObjects1[k] = gdjs.SafePromptCode.GDhelpDialogueObjects1[i];
        ++k;
    }
}
gdjs.SafePromptCode.GDhelpDialogueObjects1.length = k;}}
if (gdjs.SafePromptCode.condition1IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "SafeSuccess", false);
}}

}


};gdjs.SafePromptCode.mapOfGDgdjs_46SafePromptCode_46GDhelpButtonObjects1Objects = Hashtable.newFrom({"helpButton": gdjs.SafePromptCode.GDhelpButtonObjects1});gdjs.SafePromptCode.eventsList3 = function(runtimeScene) {

{


gdjs.SafePromptCode.condition0IsTrue_0.val = false;
{
gdjs.SafePromptCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if (gdjs.SafePromptCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("CONFIRM"), gdjs.SafePromptCode.GDCONFIRMObjects1);
gdjs.copyArray(runtimeScene.getObjects("DialogueBox"), gdjs.SafePromptCode.GDDialogueBoxObjects1);
/* Reuse gdjs.SafePromptCode.GDhelpDialogueObjects1 */
{for(var i = 0, len = gdjs.SafePromptCode.GDDialogueBoxObjects1.length ;i < len;++i) {
    gdjs.SafePromptCode.GDDialogueBoxObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.SafePromptCode.GDhelpDialogueObjects1.length ;i < len;++i) {
    gdjs.SafePromptCode.GDhelpDialogueObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.SafePromptCode.GDCONFIRMObjects1.length ;i < len;++i) {
    gdjs.SafePromptCode.GDCONFIRMObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.SafePromptCode.mapOfGDgdjs_46SafePromptCode_46GDhelpButtonObjects1Objects = Hashtable.newFrom({"helpButton": gdjs.SafePromptCode.GDhelpButtonObjects1});gdjs.SafePromptCode.mapOfGDgdjs_46SafePromptCode_46GDDialogueBoxObjects1Objects = Hashtable.newFrom({"DialogueBox": gdjs.SafePromptCode.GDDialogueBoxObjects1});gdjs.SafePromptCode.mapOfGDgdjs_46SafePromptCode_46GDCONFIRMObjects1Objects = Hashtable.newFrom({"CONFIRM": gdjs.SafePromptCode.GDCONFIRMObjects1});gdjs.SafePromptCode.eventsList4 = function(runtimeScene) {

{


gdjs.SafePromptCode.condition0IsTrue_0.val = false;
{
gdjs.SafePromptCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if (gdjs.SafePromptCode.condition0IsTrue_0.val) {
/* Reuse gdjs.SafePromptCode.GDhelpDialogueObjects1 */
/* Reuse gdjs.SafePromptCode.GDsuccessDialogueObjects1 */
gdjs.SafePromptCode.GDCONFIRMObjects1.length = 0;

gdjs.SafePromptCode.GDDialogueBoxObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.SafePromptCode.mapOfGDgdjs_46SafePromptCode_46GDDialogueBoxObjects1Objects, 60, 350, "");
}{for(var i = 0, len = gdjs.SafePromptCode.GDDialogueBoxObjects1.length ;i < len;++i) {
    gdjs.SafePromptCode.GDDialogueBoxObjects1[i].setScale(gdjs.SafePromptCode.GDDialogueBoxObjects1[i].getScale() / (2));
}
}{for(var i = 0, len = gdjs.SafePromptCode.GDDialogueBoxObjects1.length ;i < len;++i) {
    gdjs.SafePromptCode.GDDialogueBoxObjects1[i].setOpacity(215);
}
}{for(var i = 0, len = gdjs.SafePromptCode.GDhelpDialogueObjects1.length ;i < len;++i) {
    gdjs.SafePromptCode.GDhelpDialogueObjects1[i].hide(false);
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.SafePromptCode.mapOfGDgdjs_46SafePromptCode_46GDCONFIRMObjects1Objects, 425, 640, "");
}{for(var i = 0, len = gdjs.SafePromptCode.GDDialogueBoxObjects1.length ;i < len;++i) {
    gdjs.SafePromptCode.GDDialogueBoxObjects1[i].setZOrder(900);
}
}{for(var i = 0, len = gdjs.SafePromptCode.GDhelpDialogueObjects1.length ;i < len;++i) {
    gdjs.SafePromptCode.GDhelpDialogueObjects1[i].setZOrder(910);
}
}{for(var i = 0, len = gdjs.SafePromptCode.GDCONFIRMObjects1.length ;i < len;++i) {
    gdjs.SafePromptCode.GDCONFIRMObjects1[i].setZOrder(920);
}
}{for(var i = 0, len = gdjs.SafePromptCode.GDsuccessDialogueObjects1.length ;i < len;++i) {
    gdjs.SafePromptCode.GDsuccessDialogueObjects1[i].hide();
}
}}

}


};gdjs.SafePromptCode.mapOfGDgdjs_46SafePromptCode_46GDCONFIRMObjects1Objects = Hashtable.newFrom({"CONFIRM": gdjs.SafePromptCode.GDCONFIRMObjects1});gdjs.SafePromptCode.eventsList5 = function(runtimeScene) {

{


gdjs.SafePromptCode.condition0IsTrue_0.val = false;
{
gdjs.SafePromptCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if (gdjs.SafePromptCode.condition0IsTrue_0.val) {
/* Reuse gdjs.SafePromptCode.GDCONFIRMObjects1 */
gdjs.copyArray(runtimeScene.getObjects("DialogueBox"), gdjs.SafePromptCode.GDDialogueBoxObjects1);
gdjs.copyArray(runtimeScene.getObjects("helpDialogue"), gdjs.SafePromptCode.GDhelpDialogueObjects1);
{for(var i = 0, len = gdjs.SafePromptCode.GDDialogueBoxObjects1.length ;i < len;++i) {
    gdjs.SafePromptCode.GDDialogueBoxObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.SafePromptCode.GDhelpDialogueObjects1.length ;i < len;++i) {
    gdjs.SafePromptCode.GDhelpDialogueObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.SafePromptCode.GDCONFIRMObjects1.length ;i < len;++i) {
    gdjs.SafePromptCode.GDCONFIRMObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.SafePromptCode.mapOfGDgdjs_46SafePromptCode_46GDCONFIRMObjects1Objects = Hashtable.newFrom({"CONFIRM": gdjs.SafePromptCode.GDCONFIRMObjects1});gdjs.SafePromptCode.mapOfGDgdjs_46SafePromptCode_46GDexitButtonObjects1Objects = Hashtable.newFrom({"exitButton": gdjs.SafePromptCode.GDexitButtonObjects1});gdjs.SafePromptCode.eventsList6 = function(runtimeScene) {

{


gdjs.SafePromptCode.condition0IsTrue_0.val = false;
{
gdjs.SafePromptCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if (gdjs.SafePromptCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("CONFIRM"), gdjs.SafePromptCode.GDCONFIRMObjects1);
gdjs.copyArray(runtimeScene.getObjects("DialogueBox"), gdjs.SafePromptCode.GDDialogueBoxObjects1);
/* Reuse gdjs.SafePromptCode.GDexitDialogueObjects1 */
{for(var i = 0, len = gdjs.SafePromptCode.GDDialogueBoxObjects1.length ;i < len;++i) {
    gdjs.SafePromptCode.GDDialogueBoxObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.SafePromptCode.GDexitDialogueObjects1.length ;i < len;++i) {
    gdjs.SafePromptCode.GDexitDialogueObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.SafePromptCode.GDCONFIRMObjects1.length ;i < len;++i) {
    gdjs.SafePromptCode.GDCONFIRMObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.SafePromptCode.mapOfGDgdjs_46SafePromptCode_46GDexitButtonObjects1Objects = Hashtable.newFrom({"exitButton": gdjs.SafePromptCode.GDexitButtonObjects1});gdjs.SafePromptCode.mapOfGDgdjs_46SafePromptCode_46GDDialogueBoxObjects1Objects = Hashtable.newFrom({"DialogueBox": gdjs.SafePromptCode.GDDialogueBoxObjects1});gdjs.SafePromptCode.mapOfGDgdjs_46SafePromptCode_46GDYESObjects1Objects = Hashtable.newFrom({"YES": gdjs.SafePromptCode.GDYESObjects1});gdjs.SafePromptCode.mapOfGDgdjs_46SafePromptCode_46GDNOObjects1Objects = Hashtable.newFrom({"NO": gdjs.SafePromptCode.GDNOObjects1});gdjs.SafePromptCode.eventsList7 = function(runtimeScene) {

{


gdjs.SafePromptCode.condition0IsTrue_0.val = false;
{
gdjs.SafePromptCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if (gdjs.SafePromptCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("CONFIRM"), gdjs.SafePromptCode.GDCONFIRMObjects1);
gdjs.copyArray(runtimeScene.getObjects("DialogueBox"), gdjs.SafePromptCode.GDDialogueBoxObjects1);
gdjs.copyArray(runtimeScene.getObjects("NO"), gdjs.SafePromptCode.GDNOObjects1);
gdjs.copyArray(runtimeScene.getObjects("YES"), gdjs.SafePromptCode.GDYESObjects1);
/* Reuse gdjs.SafePromptCode.GDexitDialogueObjects1 */
gdjs.copyArray(runtimeScene.getObjects("helpDialogue"), gdjs.SafePromptCode.GDhelpDialogueObjects1);
/* Reuse gdjs.SafePromptCode.GDsuccessDialogueObjects1 */
{for(var i = 0, len = gdjs.SafePromptCode.GDDialogueBoxObjects1.length ;i < len;++i) {
    gdjs.SafePromptCode.GDDialogueBoxObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.SafePromptCode.GDYESObjects1.length ;i < len;++i) {
    gdjs.SafePromptCode.GDYESObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.SafePromptCode.GDNOObjects1.length ;i < len;++i) {
    gdjs.SafePromptCode.GDNOObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.SafePromptCode.GDCONFIRMObjects1.length ;i < len;++i) {
    gdjs.SafePromptCode.GDCONFIRMObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.SafePromptCode.GDhelpDialogueObjects1.length ;i < len;++i) {
    gdjs.SafePromptCode.GDhelpDialogueObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.SafePromptCode.GDsuccessDialogueObjects1.length ;i < len;++i) {
    gdjs.SafePromptCode.GDsuccessDialogueObjects1[i].hide();
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.SafePromptCode.mapOfGDgdjs_46SafePromptCode_46GDDialogueBoxObjects1Objects, 60, 350, "");
}{for(var i = 0, len = gdjs.SafePromptCode.GDDialogueBoxObjects1.length ;i < len;++i) {
    gdjs.SafePromptCode.GDDialogueBoxObjects1[i].setScale(gdjs.SafePromptCode.GDDialogueBoxObjects1[i].getScale() / (2));
}
}{for(var i = 0, len = gdjs.SafePromptCode.GDDialogueBoxObjects1.length ;i < len;++i) {
    gdjs.SafePromptCode.GDDialogueBoxObjects1[i].setOpacity(215);
}
}{for(var i = 0, len = gdjs.SafePromptCode.GDexitDialogueObjects1.length ;i < len;++i) {
    gdjs.SafePromptCode.GDexitDialogueObjects1[i].hide(false);
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.SafePromptCode.mapOfGDgdjs_46SafePromptCode_46GDYESObjects1Objects, 355, 600, "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.SafePromptCode.mapOfGDgdjs_46SafePromptCode_46GDNOObjects1Objects, 580, 600, "");
}{for(var i = 0, len = gdjs.SafePromptCode.GDDialogueBoxObjects1.length ;i < len;++i) {
    gdjs.SafePromptCode.GDDialogueBoxObjects1[i].setZOrder(900);
}
}{for(var i = 0, len = gdjs.SafePromptCode.GDexitDialogueObjects1.length ;i < len;++i) {
    gdjs.SafePromptCode.GDexitDialogueObjects1[i].setZOrder(910);
}
}{for(var i = 0, len = gdjs.SafePromptCode.GDYESObjects1.length ;i < len;++i) {
    gdjs.SafePromptCode.GDYESObjects1[i].setZOrder(920);
}
}{for(var i = 0, len = gdjs.SafePromptCode.GDNOObjects1.length ;i < len;++i) {
    gdjs.SafePromptCode.GDNOObjects1[i].setZOrder(920);
}
}}

}


};gdjs.SafePromptCode.mapOfGDgdjs_46SafePromptCode_46GDYESObjects1Objects = Hashtable.newFrom({"YES": gdjs.SafePromptCode.GDYESObjects1});gdjs.SafePromptCode.eventsList8 = function(runtimeScene) {

{


gdjs.SafePromptCode.condition0IsTrue_0.val = false;
{
gdjs.SafePromptCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if (gdjs.SafePromptCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.popScene(runtimeScene);
}}

}


};gdjs.SafePromptCode.mapOfGDgdjs_46SafePromptCode_46GDNOObjects1Objects = Hashtable.newFrom({"NO": gdjs.SafePromptCode.GDNOObjects1});gdjs.SafePromptCode.eventsList9 = function(runtimeScene) {

{


gdjs.SafePromptCode.condition0IsTrue_0.val = false;
{
gdjs.SafePromptCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if (gdjs.SafePromptCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("DialogueBox"), gdjs.SafePromptCode.GDDialogueBoxObjects1);
/* Reuse gdjs.SafePromptCode.GDNOObjects1 */
gdjs.copyArray(runtimeScene.getObjects("YES"), gdjs.SafePromptCode.GDYESObjects1);
gdjs.copyArray(runtimeScene.getObjects("exitDialogue"), gdjs.SafePromptCode.GDexitDialogueObjects1);
{for(var i = 0, len = gdjs.SafePromptCode.GDDialogueBoxObjects1.length ;i < len;++i) {
    gdjs.SafePromptCode.GDDialogueBoxObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.SafePromptCode.GDexitDialogueObjects1.length ;i < len;++i) {
    gdjs.SafePromptCode.GDexitDialogueObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.SafePromptCode.GDYESObjects1.length ;i < len;++i) {
    gdjs.SafePromptCode.GDYESObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.SafePromptCode.GDNOObjects1.length ;i < len;++i) {
    gdjs.SafePromptCode.GDNOObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.SafePromptCode.mapOfGDgdjs_46SafePromptCode_46GDYESObjects1Objects = Hashtable.newFrom({"YES": gdjs.SafePromptCode.GDYESObjects1});gdjs.SafePromptCode.mapOfGDgdjs_46SafePromptCode_46GDNOObjects1Objects = Hashtable.newFrom({"NO": gdjs.SafePromptCode.GDNOObjects1});gdjs.SafePromptCode.eventsList10 = function(runtimeScene) {

{


gdjs.SafePromptCode.condition0IsTrue_0.val = false;
gdjs.SafePromptCode.condition1IsTrue_0.val = false;
{
gdjs.SafePromptCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)) < 1800;
}if ( gdjs.SafePromptCode.condition0IsTrue_0.val ) {
{
gdjs.SafePromptCode.condition1IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)) > 540;
}}
if (gdjs.SafePromptCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("TimerMinutes"), gdjs.SafePromptCode.GDTimerMinutesObjects2);
{for(var i = 0, len = gdjs.SafePromptCode.GDTimerMinutesObjects2.length ;i < len;++i) {
    gdjs.SafePromptCode.GDTimerMinutesObjects2[i].setString(gdjs.evtTools.common.toString(Math.floor(gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)) / 60)) + ":");
}
}}

}


{


gdjs.SafePromptCode.condition0IsTrue_0.val = false;
{
gdjs.SafePromptCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)) < 600;
}if (gdjs.SafePromptCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("TimerMinutes"), gdjs.SafePromptCode.GDTimerMinutesObjects2);
{for(var i = 0, len = gdjs.SafePromptCode.GDTimerMinutesObjects2.length ;i < len;++i) {
    gdjs.SafePromptCode.GDTimerMinutesObjects2[i].setString("0" + gdjs.evtTools.common.toString(Math.floor(gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)) / 60)) + ":");
}
}}

}


{


gdjs.SafePromptCode.condition0IsTrue_0.val = false;
{
gdjs.SafePromptCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)) < 1800;
}if (gdjs.SafePromptCode.condition0IsTrue_0.val) {
{runtimeScene.getGame().getVariables().getFromIndex(4).sub(gdjs.evtTools.runtimeScene.getElapsedTimeInSeconds(runtimeScene));
}}

}


{


gdjs.SafePromptCode.condition0IsTrue_0.val = false;
gdjs.SafePromptCode.condition1IsTrue_0.val = false;
{
gdjs.SafePromptCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4)) < 60;
}if ( gdjs.SafePromptCode.condition0IsTrue_0.val ) {
{
gdjs.SafePromptCode.condition1IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4)) > 9;
}}
if (gdjs.SafePromptCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("TimerSeconds"), gdjs.SafePromptCode.GDTimerSecondsObjects2);
{for(var i = 0, len = gdjs.SafePromptCode.GDTimerSecondsObjects2.length ;i < len;++i) {
    gdjs.SafePromptCode.GDTimerSecondsObjects2[i].setString(gdjs.evtTools.common.toString(Math.floor(gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4)))));
}
}}

}


{


gdjs.SafePromptCode.condition0IsTrue_0.val = false;
{
gdjs.SafePromptCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4)) < 10;
}if (gdjs.SafePromptCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("TimerSeconds"), gdjs.SafePromptCode.GDTimerSecondsObjects2);
{for(var i = 0, len = gdjs.SafePromptCode.GDTimerSecondsObjects2.length ;i < len;++i) {
    gdjs.SafePromptCode.GDTimerSecondsObjects2[i].setString("0" + gdjs.evtTools.common.toString(Math.floor(gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4)))));
}
}}

}


{


gdjs.SafePromptCode.condition0IsTrue_0.val = false;
{
gdjs.SafePromptCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)) == 0;
}if (gdjs.SafePromptCode.condition0IsTrue_0.val) {
{runtimeScene.getGame().getVariables().getFromIndex(4).setNumber(59);
}}

}


{


gdjs.SafePromptCode.condition0IsTrue_0.val = false;
{
gdjs.SafePromptCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)) <= 0;
}if (gdjs.SafePromptCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "GameOver", false);
}}

}


};gdjs.SafePromptCode.eventsList11 = function(runtimeScene) {

{


{
{runtimeScene.getGame().getVariables().getFromIndex(3).sub(gdjs.evtTools.runtimeScene.getElapsedTimeInSeconds(runtimeScene));
}
{ //Subevents
gdjs.SafePromptCode.eventsList10(runtimeScene);} //End of subevents
}

}


};gdjs.SafePromptCode.eventsList12 = function(runtimeScene) {

{



}


{


gdjs.SafePromptCode.condition0IsTrue_0.val = false;
{
gdjs.SafePromptCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.SafePromptCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("CodePrompt"), gdjs.SafePromptCode.GDCodePromptObjects1);
gdjs.copyArray(runtimeScene.getObjects("Instructions"), gdjs.SafePromptCode.GDInstructionsObjects1);
gdjs.copyArray(runtimeScene.getObjects("body"), gdjs.SafePromptCode.GDbodyObjects1);
gdjs.copyArray(runtimeScene.getObjects("box1"), gdjs.SafePromptCode.GDbox1Objects1);
gdjs.copyArray(runtimeScene.getObjects("box2"), gdjs.SafePromptCode.GDbox2Objects1);
gdjs.copyArray(runtimeScene.getObjects("box3"), gdjs.SafePromptCode.GDbox3Objects1);
gdjs.copyArray(runtimeScene.getObjects("box4"), gdjs.SafePromptCode.GDbox4Objects1);
gdjs.copyArray(runtimeScene.getObjects("exitButton"), gdjs.SafePromptCode.GDexitButtonObjects1);
gdjs.copyArray(runtimeScene.getObjects("exitDialogue"), gdjs.SafePromptCode.GDexitDialogueObjects1);
gdjs.copyArray(runtimeScene.getObjects("helpButton"), gdjs.SafePromptCode.GDhelpButtonObjects1);
gdjs.copyArray(runtimeScene.getObjects("helpDialogue"), gdjs.SafePromptCode.GDhelpDialogueObjects1);
gdjs.copyArray(runtimeScene.getObjects("if"), gdjs.SafePromptCode.GDifObjects1);
gdjs.copyArray(runtimeScene.getObjects("pieceChange"), gdjs.SafePromptCode.GDpieceChangeObjects1);
gdjs.copyArray(runtimeScene.getObjects("pieceClicks"), gdjs.SafePromptCode.GDpieceClicksObjects1);
gdjs.copyArray(runtimeScene.getObjects("pieceDirection"), gdjs.SafePromptCode.GDpieceDirectionObjects1);
gdjs.copyArray(runtimeScene.getObjects("pieceSound"), gdjs.SafePromptCode.GDpieceSoundObjects1);
gdjs.copyArray(runtimeScene.getObjects("successDialogue"), gdjs.SafePromptCode.GDsuccessDialogueObjects1);
gdjs.copyArray(runtimeScene.getObjects("while"), gdjs.SafePromptCode.GDwhileObjects1);
gdjs.SafePromptCode.GDDialogueBoxObjects1.length = 0;

gdjs.SafePromptCode.GDNextObjects1.length = 0;

{for(var i = 0, len = gdjs.SafePromptCode.GDhelpDialogueObjects1.length ;i < len;++i) {
    gdjs.SafePromptCode.GDhelpDialogueObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.SafePromptCode.GDexitDialogueObjects1.length ;i < len;++i) {
    gdjs.SafePromptCode.GDexitDialogueObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.SafePromptCode.GDCodePromptObjects1.length ;i < len;++i) {
    gdjs.SafePromptCode.GDCodePromptObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.SafePromptCode.GDInstructionsObjects1.length ;i < len;++i) {
    gdjs.SafePromptCode.GDInstructionsObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.SafePromptCode.GDwhileObjects1.length ;i < len;++i) {
    gdjs.SafePromptCode.GDwhileObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.SafePromptCode.GDifObjects1.length ;i < len;++i) {
    gdjs.SafePromptCode.GDifObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.SafePromptCode.GDbodyObjects1.length ;i < len;++i) {
    gdjs.SafePromptCode.GDbodyObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.SafePromptCode.GDpieceClicksObjects1.length ;i < len;++i) {
    gdjs.SafePromptCode.GDpieceClicksObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.SafePromptCode.GDpieceDirectionObjects1.length ;i < len;++i) {
    gdjs.SafePromptCode.GDpieceDirectionObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.SafePromptCode.GDpieceSoundObjects1.length ;i < len;++i) {
    gdjs.SafePromptCode.GDpieceSoundObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.SafePromptCode.GDpieceChangeObjects1.length ;i < len;++i) {
    gdjs.SafePromptCode.GDpieceChangeObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.SafePromptCode.GDbox1Objects1.length ;i < len;++i) {
    gdjs.SafePromptCode.GDbox1Objects1[i].hide();
}
}{for(var i = 0, len = gdjs.SafePromptCode.GDbox2Objects1.length ;i < len;++i) {
    gdjs.SafePromptCode.GDbox2Objects1[i].hide();
}
}{for(var i = 0, len = gdjs.SafePromptCode.GDbox3Objects1.length ;i < len;++i) {
    gdjs.SafePromptCode.GDbox3Objects1[i].hide();
}
}{for(var i = 0, len = gdjs.SafePromptCode.GDbox4Objects1.length ;i < len;++i) {
    gdjs.SafePromptCode.GDbox4Objects1[i].hide();
}
}{for(var i = 0, len = gdjs.SafePromptCode.GDhelpButtonObjects1.length ;i < len;++i) {
    gdjs.SafePromptCode.GDhelpButtonObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.SafePromptCode.GDexitButtonObjects1.length ;i < len;++i) {
    gdjs.SafePromptCode.GDexitButtonObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.SafePromptCode.GDsuccessDialogueObjects1.length ;i < len;++i) {
    gdjs.SafePromptCode.GDsuccessDialogueObjects1[i].hide();
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.SafePromptCode.mapOfGDgdjs_46SafePromptCode_46GDDialogueBoxObjects1Objects, 60, 576, "");
}{for(var i = 0, len = gdjs.SafePromptCode.GDDialogueBoxObjects1.length ;i < len;++i) {
    gdjs.SafePromptCode.GDDialogueBoxObjects1[i].setScale(gdjs.SafePromptCode.GDDialogueBoxObjects1[i].getScale() / (2));
}
}{for(var i = 0, len = gdjs.SafePromptCode.GDDialogueBoxObjects1.length ;i < len;++i) {
    gdjs.SafePromptCode.GDDialogueBoxObjects1[i].setOpacity(215);
}
}{for(var i = 0, len = gdjs.SafePromptCode.GDDialogueBoxObjects1.length ;i < len;++i) {
    gdjs.SafePromptCode.GDDialogueBoxObjects1[i].setZOrder(20);
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.SafePromptCode.mapOfGDgdjs_46SafePromptCode_46GDNextObjects1Objects, 739, 881, "");
}{for(var i = 0, len = gdjs.SafePromptCode.GDNextObjects1.length ;i < len;++i) {
    gdjs.SafePromptCode.GDNextObjects1[i].setZOrder(25);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Next"), gdjs.SafePromptCode.GDNextObjects1);

gdjs.SafePromptCode.condition0IsTrue_0.val = false;
{
gdjs.SafePromptCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.SafePromptCode.mapOfGDgdjs_46SafePromptCode_46GDNextObjects1Objects, runtimeScene, true, false);
}if (gdjs.SafePromptCode.condition0IsTrue_0.val) {
/* Reuse gdjs.SafePromptCode.GDNextObjects1 */
{for(var i = 0, len = gdjs.SafePromptCode.GDNextObjects1.length ;i < len;++i) {
    gdjs.SafePromptCode.GDNextObjects1[i].setColor("255;255;255");
}
}
{ //Subevents
gdjs.SafePromptCode.eventsList0(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Next"), gdjs.SafePromptCode.GDNextObjects1);

gdjs.SafePromptCode.condition0IsTrue_0.val = false;
{
gdjs.SafePromptCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.SafePromptCode.mapOfGDgdjs_46SafePromptCode_46GDNextObjects1Objects, runtimeScene, true, true);
}if (gdjs.SafePromptCode.condition0IsTrue_0.val) {
/* Reuse gdjs.SafePromptCode.GDNextObjects1 */
{for(var i = 0, len = gdjs.SafePromptCode.GDNextObjects1.length ;i < len;++i) {
    gdjs.SafePromptCode.GDNextObjects1[i].setColor("155;155;155");
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("successDialogue"), gdjs.SafePromptCode.GDsuccessDialogueObjects1);

gdjs.SafePromptCode.condition0IsTrue_0.val = false;
gdjs.SafePromptCode.condition1IsTrue_0.val = false;
{
gdjs.SafePromptCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if ( gdjs.SafePromptCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.SafePromptCode.GDsuccessDialogueObjects1.length;i<l;++i) {
    if ( !(gdjs.SafePromptCode.GDsuccessDialogueObjects1[i].isVisible()) ) {
        gdjs.SafePromptCode.condition1IsTrue_0.val = true;
        gdjs.SafePromptCode.GDsuccessDialogueObjects1[k] = gdjs.SafePromptCode.GDsuccessDialogueObjects1[i];
        ++k;
    }
}
gdjs.SafePromptCode.GDsuccessDialogueObjects1.length = k;}}
if (gdjs.SafePromptCode.condition1IsTrue_0.val) {

{ //Subevents
gdjs.SafePromptCode.eventsList1(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("CONFIRM"), gdjs.SafePromptCode.GDCONFIRMObjects1);

gdjs.SafePromptCode.condition0IsTrue_0.val = false;
{
gdjs.SafePromptCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.SafePromptCode.mapOfGDgdjs_46SafePromptCode_46GDCONFIRMObjects1Objects, runtimeScene, true, false);
}if (gdjs.SafePromptCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.SafePromptCode.eventsList2(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("helpButton"), gdjs.SafePromptCode.GDhelpButtonObjects1);
gdjs.copyArray(runtimeScene.getObjects("helpDialogue"), gdjs.SafePromptCode.GDhelpDialogueObjects1);

gdjs.SafePromptCode.condition0IsTrue_0.val = false;
gdjs.SafePromptCode.condition1IsTrue_0.val = false;
{
gdjs.SafePromptCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.SafePromptCode.mapOfGDgdjs_46SafePromptCode_46GDhelpButtonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.SafePromptCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.SafePromptCode.GDhelpDialogueObjects1.length;i<l;++i) {
    if ( gdjs.SafePromptCode.GDhelpDialogueObjects1[i].isVisible() ) {
        gdjs.SafePromptCode.condition1IsTrue_0.val = true;
        gdjs.SafePromptCode.GDhelpDialogueObjects1[k] = gdjs.SafePromptCode.GDhelpDialogueObjects1[i];
        ++k;
    }
}
gdjs.SafePromptCode.GDhelpDialogueObjects1.length = k;}}
if (gdjs.SafePromptCode.condition1IsTrue_0.val) {

{ //Subevents
gdjs.SafePromptCode.eventsList3(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("helpButton"), gdjs.SafePromptCode.GDhelpButtonObjects1);
gdjs.copyArray(runtimeScene.getObjects("helpDialogue"), gdjs.SafePromptCode.GDhelpDialogueObjects1);
gdjs.copyArray(runtimeScene.getObjects("successDialogue"), gdjs.SafePromptCode.GDsuccessDialogueObjects1);

gdjs.SafePromptCode.condition0IsTrue_0.val = false;
gdjs.SafePromptCode.condition1IsTrue_0.val = false;
gdjs.SafePromptCode.condition2IsTrue_0.val = false;
{
gdjs.SafePromptCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.SafePromptCode.mapOfGDgdjs_46SafePromptCode_46GDhelpButtonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.SafePromptCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.SafePromptCode.GDhelpDialogueObjects1.length;i<l;++i) {
    if ( !(gdjs.SafePromptCode.GDhelpDialogueObjects1[i].isVisible()) ) {
        gdjs.SafePromptCode.condition1IsTrue_0.val = true;
        gdjs.SafePromptCode.GDhelpDialogueObjects1[k] = gdjs.SafePromptCode.GDhelpDialogueObjects1[i];
        ++k;
    }
}
gdjs.SafePromptCode.GDhelpDialogueObjects1.length = k;}if ( gdjs.SafePromptCode.condition1IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.SafePromptCode.GDsuccessDialogueObjects1.length;i<l;++i) {
    if ( !(gdjs.SafePromptCode.GDsuccessDialogueObjects1[i].isVisible()) ) {
        gdjs.SafePromptCode.condition2IsTrue_0.val = true;
        gdjs.SafePromptCode.GDsuccessDialogueObjects1[k] = gdjs.SafePromptCode.GDsuccessDialogueObjects1[i];
        ++k;
    }
}
gdjs.SafePromptCode.GDsuccessDialogueObjects1.length = k;}}
}
if (gdjs.SafePromptCode.condition2IsTrue_0.val) {

{ //Subevents
gdjs.SafePromptCode.eventsList4(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("CONFIRM"), gdjs.SafePromptCode.GDCONFIRMObjects1);

gdjs.SafePromptCode.condition0IsTrue_0.val = false;
{
gdjs.SafePromptCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.SafePromptCode.mapOfGDgdjs_46SafePromptCode_46GDCONFIRMObjects1Objects, runtimeScene, true, false);
}if (gdjs.SafePromptCode.condition0IsTrue_0.val) {
/* Reuse gdjs.SafePromptCode.GDCONFIRMObjects1 */
{for(var i = 0, len = gdjs.SafePromptCode.GDCONFIRMObjects1.length ;i < len;++i) {
    gdjs.SafePromptCode.GDCONFIRMObjects1[i].setColor("255;255;255");
}
}
{ //Subevents
gdjs.SafePromptCode.eventsList5(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("CONFIRM"), gdjs.SafePromptCode.GDCONFIRMObjects1);

gdjs.SafePromptCode.condition0IsTrue_0.val = false;
{
gdjs.SafePromptCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.SafePromptCode.mapOfGDgdjs_46SafePromptCode_46GDCONFIRMObjects1Objects, runtimeScene, true, true);
}if (gdjs.SafePromptCode.condition0IsTrue_0.val) {
/* Reuse gdjs.SafePromptCode.GDCONFIRMObjects1 */
{for(var i = 0, len = gdjs.SafePromptCode.GDCONFIRMObjects1.length ;i < len;++i) {
    gdjs.SafePromptCode.GDCONFIRMObjects1[i].setColor("155;155;155");
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("exitButton"), gdjs.SafePromptCode.GDexitButtonObjects1);
gdjs.copyArray(runtimeScene.getObjects("exitDialogue"), gdjs.SafePromptCode.GDexitDialogueObjects1);

gdjs.SafePromptCode.condition0IsTrue_0.val = false;
gdjs.SafePromptCode.condition1IsTrue_0.val = false;
{
gdjs.SafePromptCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.SafePromptCode.mapOfGDgdjs_46SafePromptCode_46GDexitButtonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.SafePromptCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.SafePromptCode.GDexitDialogueObjects1.length;i<l;++i) {
    if ( gdjs.SafePromptCode.GDexitDialogueObjects1[i].isVisible() ) {
        gdjs.SafePromptCode.condition1IsTrue_0.val = true;
        gdjs.SafePromptCode.GDexitDialogueObjects1[k] = gdjs.SafePromptCode.GDexitDialogueObjects1[i];
        ++k;
    }
}
gdjs.SafePromptCode.GDexitDialogueObjects1.length = k;}}
if (gdjs.SafePromptCode.condition1IsTrue_0.val) {

{ //Subevents
gdjs.SafePromptCode.eventsList6(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("exitButton"), gdjs.SafePromptCode.GDexitButtonObjects1);
gdjs.copyArray(runtimeScene.getObjects("exitDialogue"), gdjs.SafePromptCode.GDexitDialogueObjects1);
gdjs.copyArray(runtimeScene.getObjects("successDialogue"), gdjs.SafePromptCode.GDsuccessDialogueObjects1);

gdjs.SafePromptCode.condition0IsTrue_0.val = false;
gdjs.SafePromptCode.condition1IsTrue_0.val = false;
gdjs.SafePromptCode.condition2IsTrue_0.val = false;
{
gdjs.SafePromptCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.SafePromptCode.mapOfGDgdjs_46SafePromptCode_46GDexitButtonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.SafePromptCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.SafePromptCode.GDexitDialogueObjects1.length;i<l;++i) {
    if ( !(gdjs.SafePromptCode.GDexitDialogueObjects1[i].isVisible()) ) {
        gdjs.SafePromptCode.condition1IsTrue_0.val = true;
        gdjs.SafePromptCode.GDexitDialogueObjects1[k] = gdjs.SafePromptCode.GDexitDialogueObjects1[i];
        ++k;
    }
}
gdjs.SafePromptCode.GDexitDialogueObjects1.length = k;}if ( gdjs.SafePromptCode.condition1IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.SafePromptCode.GDsuccessDialogueObjects1.length;i<l;++i) {
    if ( !(gdjs.SafePromptCode.GDsuccessDialogueObjects1[i].isVisible()) ) {
        gdjs.SafePromptCode.condition2IsTrue_0.val = true;
        gdjs.SafePromptCode.GDsuccessDialogueObjects1[k] = gdjs.SafePromptCode.GDsuccessDialogueObjects1[i];
        ++k;
    }
}
gdjs.SafePromptCode.GDsuccessDialogueObjects1.length = k;}}
}
if (gdjs.SafePromptCode.condition2IsTrue_0.val) {

{ //Subevents
gdjs.SafePromptCode.eventsList7(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("YES"), gdjs.SafePromptCode.GDYESObjects1);

gdjs.SafePromptCode.condition0IsTrue_0.val = false;
{
gdjs.SafePromptCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.SafePromptCode.mapOfGDgdjs_46SafePromptCode_46GDYESObjects1Objects, runtimeScene, true, false);
}if (gdjs.SafePromptCode.condition0IsTrue_0.val) {
/* Reuse gdjs.SafePromptCode.GDYESObjects1 */
{for(var i = 0, len = gdjs.SafePromptCode.GDYESObjects1.length ;i < len;++i) {
    gdjs.SafePromptCode.GDYESObjects1[i].setColor("255;255;255");
}
}
{ //Subevents
gdjs.SafePromptCode.eventsList8(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("NO"), gdjs.SafePromptCode.GDNOObjects1);

gdjs.SafePromptCode.condition0IsTrue_0.val = false;
{
gdjs.SafePromptCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.SafePromptCode.mapOfGDgdjs_46SafePromptCode_46GDNOObjects1Objects, runtimeScene, true, false);
}if (gdjs.SafePromptCode.condition0IsTrue_0.val) {
/* Reuse gdjs.SafePromptCode.GDNOObjects1 */
{for(var i = 0, len = gdjs.SafePromptCode.GDNOObjects1.length ;i < len;++i) {
    gdjs.SafePromptCode.GDNOObjects1[i].setColor("255;255;255");
}
}
{ //Subevents
gdjs.SafePromptCode.eventsList9(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("YES"), gdjs.SafePromptCode.GDYESObjects1);

gdjs.SafePromptCode.condition0IsTrue_0.val = false;
{
gdjs.SafePromptCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.SafePromptCode.mapOfGDgdjs_46SafePromptCode_46GDYESObjects1Objects, runtimeScene, true, true);
}if (gdjs.SafePromptCode.condition0IsTrue_0.val) {
/* Reuse gdjs.SafePromptCode.GDYESObjects1 */
{for(var i = 0, len = gdjs.SafePromptCode.GDYESObjects1.length ;i < len;++i) {
    gdjs.SafePromptCode.GDYESObjects1[i].setColor("155;155;155");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("NO"), gdjs.SafePromptCode.GDNOObjects1);

gdjs.SafePromptCode.condition0IsTrue_0.val = false;
{
gdjs.SafePromptCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.SafePromptCode.mapOfGDgdjs_46SafePromptCode_46GDNOObjects1Objects, runtimeScene, true, true);
}if (gdjs.SafePromptCode.condition0IsTrue_0.val) {
/* Reuse gdjs.SafePromptCode.GDNOObjects1 */
{for(var i = 0, len = gdjs.SafePromptCode.GDNOObjects1.length ;i < len;++i) {
    gdjs.SafePromptCode.GDNOObjects1[i].setColor("155;155;155");
}
}}

}


{


gdjs.SafePromptCode.eventsList11(runtimeScene);
}


};

gdjs.SafePromptCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.SafePromptCode.GDBackgroundObjects1.length = 0;
gdjs.SafePromptCode.GDBackgroundObjects2.length = 0;
gdjs.SafePromptCode.GDBackgroundObjects3.length = 0;
gdjs.SafePromptCode.GDCodePromptObjects1.length = 0;
gdjs.SafePromptCode.GDCodePromptObjects2.length = 0;
gdjs.SafePromptCode.GDCodePromptObjects3.length = 0;
gdjs.SafePromptCode.GDInstructionsObjects1.length = 0;
gdjs.SafePromptCode.GDInstructionsObjects2.length = 0;
gdjs.SafePromptCode.GDInstructionsObjects3.length = 0;
gdjs.SafePromptCode.GDwhileObjects1.length = 0;
gdjs.SafePromptCode.GDwhileObjects2.length = 0;
gdjs.SafePromptCode.GDwhileObjects3.length = 0;
gdjs.SafePromptCode.GDifObjects1.length = 0;
gdjs.SafePromptCode.GDifObjects2.length = 0;
gdjs.SafePromptCode.GDifObjects3.length = 0;
gdjs.SafePromptCode.GDbodyObjects1.length = 0;
gdjs.SafePromptCode.GDbodyObjects2.length = 0;
gdjs.SafePromptCode.GDbodyObjects3.length = 0;
gdjs.SafePromptCode.GDpieceClicksObjects1.length = 0;
gdjs.SafePromptCode.GDpieceClicksObjects2.length = 0;
gdjs.SafePromptCode.GDpieceClicksObjects3.length = 0;
gdjs.SafePromptCode.GDpieceDirectionObjects1.length = 0;
gdjs.SafePromptCode.GDpieceDirectionObjects2.length = 0;
gdjs.SafePromptCode.GDpieceDirectionObjects3.length = 0;
gdjs.SafePromptCode.GDpieceSoundObjects1.length = 0;
gdjs.SafePromptCode.GDpieceSoundObjects2.length = 0;
gdjs.SafePromptCode.GDpieceSoundObjects3.length = 0;
gdjs.SafePromptCode.GDpieceChangeObjects1.length = 0;
gdjs.SafePromptCode.GDpieceChangeObjects2.length = 0;
gdjs.SafePromptCode.GDpieceChangeObjects3.length = 0;
gdjs.SafePromptCode.GDbox1Objects1.length = 0;
gdjs.SafePromptCode.GDbox1Objects2.length = 0;
gdjs.SafePromptCode.GDbox1Objects3.length = 0;
gdjs.SafePromptCode.GDbox2Objects1.length = 0;
gdjs.SafePromptCode.GDbox2Objects2.length = 0;
gdjs.SafePromptCode.GDbox2Objects3.length = 0;
gdjs.SafePromptCode.GDbox3Objects1.length = 0;
gdjs.SafePromptCode.GDbox3Objects2.length = 0;
gdjs.SafePromptCode.GDbox3Objects3.length = 0;
gdjs.SafePromptCode.GDbox4Objects1.length = 0;
gdjs.SafePromptCode.GDbox4Objects2.length = 0;
gdjs.SafePromptCode.GDbox4Objects3.length = 0;
gdjs.SafePromptCode.GDSuccessObjects1.length = 0;
gdjs.SafePromptCode.GDSuccessObjects2.length = 0;
gdjs.SafePromptCode.GDSuccessObjects3.length = 0;
gdjs.SafePromptCode.GDDialogueBoxObjects1.length = 0;
gdjs.SafePromptCode.GDDialogueBoxObjects2.length = 0;
gdjs.SafePromptCode.GDDialogueBoxObjects3.length = 0;
gdjs.SafePromptCode.GDhelpDialogueObjects1.length = 0;
gdjs.SafePromptCode.GDhelpDialogueObjects2.length = 0;
gdjs.SafePromptCode.GDhelpDialogueObjects3.length = 0;
gdjs.SafePromptCode.GDexitButtonObjects1.length = 0;
gdjs.SafePromptCode.GDexitButtonObjects2.length = 0;
gdjs.SafePromptCode.GDexitButtonObjects3.length = 0;
gdjs.SafePromptCode.GDhelpButtonObjects1.length = 0;
gdjs.SafePromptCode.GDhelpButtonObjects2.length = 0;
gdjs.SafePromptCode.GDhelpButtonObjects3.length = 0;
gdjs.SafePromptCode.GDexitDialogueObjects1.length = 0;
gdjs.SafePromptCode.GDexitDialogueObjects2.length = 0;
gdjs.SafePromptCode.GDexitDialogueObjects3.length = 0;
gdjs.SafePromptCode.GDYESObjects1.length = 0;
gdjs.SafePromptCode.GDYESObjects2.length = 0;
gdjs.SafePromptCode.GDYESObjects3.length = 0;
gdjs.SafePromptCode.GDNOObjects1.length = 0;
gdjs.SafePromptCode.GDNOObjects2.length = 0;
gdjs.SafePromptCode.GDNOObjects3.length = 0;
gdjs.SafePromptCode.GDCONFIRMObjects1.length = 0;
gdjs.SafePromptCode.GDCONFIRMObjects2.length = 0;
gdjs.SafePromptCode.GDCONFIRMObjects3.length = 0;
gdjs.SafePromptCode.GDDialogueObjects1.length = 0;
gdjs.SafePromptCode.GDDialogueObjects2.length = 0;
gdjs.SafePromptCode.GDDialogueObjects3.length = 0;
gdjs.SafePromptCode.GDNextObjects1.length = 0;
gdjs.SafePromptCode.GDNextObjects2.length = 0;
gdjs.SafePromptCode.GDNextObjects3.length = 0;
gdjs.SafePromptCode.GDsuccessDialogueObjects1.length = 0;
gdjs.SafePromptCode.GDsuccessDialogueObjects2.length = 0;
gdjs.SafePromptCode.GDsuccessDialogueObjects3.length = 0;
gdjs.SafePromptCode.GDTimerSecondsObjects1.length = 0;
gdjs.SafePromptCode.GDTimerSecondsObjects2.length = 0;
gdjs.SafePromptCode.GDTimerSecondsObjects3.length = 0;
gdjs.SafePromptCode.GDTimerMinutesObjects1.length = 0;
gdjs.SafePromptCode.GDTimerMinutesObjects2.length = 0;
gdjs.SafePromptCode.GDTimerMinutesObjects3.length = 0;

gdjs.SafePromptCode.eventsList12(runtimeScene);
return;

}

gdjs['SafePromptCode'] = gdjs.SafePromptCode;
