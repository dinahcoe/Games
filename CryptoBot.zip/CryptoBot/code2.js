gdjs.TrashPromptCode = {};
gdjs.TrashPromptCode.GDBackgroundObjects1= [];
gdjs.TrashPromptCode.GDBackgroundObjects2= [];
gdjs.TrashPromptCode.GDBackgroundObjects3= [];
gdjs.TrashPromptCode.GDCodePromptObjects1= [];
gdjs.TrashPromptCode.GDCodePromptObjects2= [];
gdjs.TrashPromptCode.GDCodePromptObjects3= [];
gdjs.TrashPromptCode.GDInstructionsObjects1= [];
gdjs.TrashPromptCode.GDInstructionsObjects2= [];
gdjs.TrashPromptCode.GDInstructionsObjects3= [];
gdjs.TrashPromptCode.GDforEachObjects1= [];
gdjs.TrashPromptCode.GDforEachObjects2= [];
gdjs.TrashPromptCode.GDforEachObjects3= [];
gdjs.TrashPromptCode.GDifObjects1= [];
gdjs.TrashPromptCode.GDifObjects2= [];
gdjs.TrashPromptCode.GDifObjects3= [];
gdjs.TrashPromptCode.GDbodyObjects1= [];
gdjs.TrashPromptCode.GDbodyObjects2= [];
gdjs.TrashPromptCode.GDbodyObjects3= [];
gdjs.TrashPromptCode.GDpieceBasketObjects1= [];
gdjs.TrashPromptCode.GDpieceBasketObjects2= [];
gdjs.TrashPromptCode.GDpieceBasketObjects3= [];
gdjs.TrashPromptCode.GDpiecePaperObjects1= [];
gdjs.TrashPromptCode.GDpiecePaperObjects2= [];
gdjs.TrashPromptCode.GDpiecePaperObjects3= [];
gdjs.TrashPromptCode.GDpieceTargetObjects1= [];
gdjs.TrashPromptCode.GDpieceTargetObjects2= [];
gdjs.TrashPromptCode.GDpieceTargetObjects3= [];
gdjs.TrashPromptCode.GDpieceContentsObjects1= [];
gdjs.TrashPromptCode.GDpieceContentsObjects2= [];
gdjs.TrashPromptCode.GDpieceContentsObjects3= [];
gdjs.TrashPromptCode.GDbox1Objects1= [];
gdjs.TrashPromptCode.GDbox1Objects2= [];
gdjs.TrashPromptCode.GDbox1Objects3= [];
gdjs.TrashPromptCode.GDbox2Objects1= [];
gdjs.TrashPromptCode.GDbox2Objects2= [];
gdjs.TrashPromptCode.GDbox2Objects3= [];
gdjs.TrashPromptCode.GDbox3Objects1= [];
gdjs.TrashPromptCode.GDbox3Objects2= [];
gdjs.TrashPromptCode.GDbox3Objects3= [];
gdjs.TrashPromptCode.GDbox4Objects1= [];
gdjs.TrashPromptCode.GDbox4Objects2= [];
gdjs.TrashPromptCode.GDbox4Objects3= [];
gdjs.TrashPromptCode.GDSuccessObjects1= [];
gdjs.TrashPromptCode.GDSuccessObjects2= [];
gdjs.TrashPromptCode.GDSuccessObjects3= [];
gdjs.TrashPromptCode.GDDialogueBoxObjects1= [];
gdjs.TrashPromptCode.GDDialogueBoxObjects2= [];
gdjs.TrashPromptCode.GDDialogueBoxObjects3= [];
gdjs.TrashPromptCode.GDhelpDialogueObjects1= [];
gdjs.TrashPromptCode.GDhelpDialogueObjects2= [];
gdjs.TrashPromptCode.GDhelpDialogueObjects3= [];
gdjs.TrashPromptCode.GDexitButtonObjects1= [];
gdjs.TrashPromptCode.GDexitButtonObjects2= [];
gdjs.TrashPromptCode.GDexitButtonObjects3= [];
gdjs.TrashPromptCode.GDhelpButtonObjects1= [];
gdjs.TrashPromptCode.GDhelpButtonObjects2= [];
gdjs.TrashPromptCode.GDhelpButtonObjects3= [];
gdjs.TrashPromptCode.GDexitDialogueObjects1= [];
gdjs.TrashPromptCode.GDexitDialogueObjects2= [];
gdjs.TrashPromptCode.GDexitDialogueObjects3= [];
gdjs.TrashPromptCode.GDYESObjects1= [];
gdjs.TrashPromptCode.GDYESObjects2= [];
gdjs.TrashPromptCode.GDYESObjects3= [];
gdjs.TrashPromptCode.GDNOObjects1= [];
gdjs.TrashPromptCode.GDNOObjects2= [];
gdjs.TrashPromptCode.GDNOObjects3= [];
gdjs.TrashPromptCode.GDCONFIRMObjects1= [];
gdjs.TrashPromptCode.GDCONFIRMObjects2= [];
gdjs.TrashPromptCode.GDCONFIRMObjects3= [];
gdjs.TrashPromptCode.GDDialogueObjects1= [];
gdjs.TrashPromptCode.GDDialogueObjects2= [];
gdjs.TrashPromptCode.GDDialogueObjects3= [];
gdjs.TrashPromptCode.GDNextObjects1= [];
gdjs.TrashPromptCode.GDNextObjects2= [];
gdjs.TrashPromptCode.GDNextObjects3= [];
gdjs.TrashPromptCode.GDsuccessDialogueObjects1= [];
gdjs.TrashPromptCode.GDsuccessDialogueObjects2= [];
gdjs.TrashPromptCode.GDsuccessDialogueObjects3= [];
gdjs.TrashPromptCode.GDTimerMinutesObjects1= [];
gdjs.TrashPromptCode.GDTimerMinutesObjects2= [];
gdjs.TrashPromptCode.GDTimerMinutesObjects3= [];
gdjs.TrashPromptCode.GDTimerSecondsObjects1= [];
gdjs.TrashPromptCode.GDTimerSecondsObjects2= [];
gdjs.TrashPromptCode.GDTimerSecondsObjects3= [];

gdjs.TrashPromptCode.conditionTrue_0 = {val:false};
gdjs.TrashPromptCode.condition0IsTrue_0 = {val:false};
gdjs.TrashPromptCode.condition1IsTrue_0 = {val:false};
gdjs.TrashPromptCode.condition2IsTrue_0 = {val:false};
gdjs.TrashPromptCode.condition3IsTrue_0 = {val:false};
gdjs.TrashPromptCode.condition4IsTrue_0 = {val:false};


gdjs.TrashPromptCode.mapOfGDgdjs_46TrashPromptCode_46GDDialogueBoxObjects1Objects = Hashtable.newFrom({"DialogueBox": gdjs.TrashPromptCode.GDDialogueBoxObjects1});gdjs.TrashPromptCode.mapOfGDgdjs_46TrashPromptCode_46GDNextObjects1Objects = Hashtable.newFrom({"Next": gdjs.TrashPromptCode.GDNextObjects1});gdjs.TrashPromptCode.mapOfGDgdjs_46TrashPromptCode_46GDNextObjects1Objects = Hashtable.newFrom({"Next": gdjs.TrashPromptCode.GDNextObjects1});gdjs.TrashPromptCode.eventsList0 = function(runtimeScene) {

{


gdjs.TrashPromptCode.condition0IsTrue_0.val = false;
{
gdjs.TrashPromptCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if (gdjs.TrashPromptCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("CodePrompt"), gdjs.TrashPromptCode.GDCodePromptObjects1);
gdjs.copyArray(runtimeScene.getObjects("Dialogue"), gdjs.TrashPromptCode.GDDialogueObjects1);
gdjs.copyArray(runtimeScene.getObjects("DialogueBox"), gdjs.TrashPromptCode.GDDialogueBoxObjects1);
gdjs.copyArray(runtimeScene.getObjects("Instructions"), gdjs.TrashPromptCode.GDInstructionsObjects1);
/* Reuse gdjs.TrashPromptCode.GDNextObjects1 */
gdjs.copyArray(runtimeScene.getObjects("body"), gdjs.TrashPromptCode.GDbodyObjects1);
gdjs.copyArray(runtimeScene.getObjects("box1"), gdjs.TrashPromptCode.GDbox1Objects1);
gdjs.copyArray(runtimeScene.getObjects("box2"), gdjs.TrashPromptCode.GDbox2Objects1);
gdjs.copyArray(runtimeScene.getObjects("box3"), gdjs.TrashPromptCode.GDbox3Objects1);
gdjs.copyArray(runtimeScene.getObjects("box4"), gdjs.TrashPromptCode.GDbox4Objects1);
gdjs.copyArray(runtimeScene.getObjects("exitButton"), gdjs.TrashPromptCode.GDexitButtonObjects1);
gdjs.copyArray(runtimeScene.getObjects("forEach"), gdjs.TrashPromptCode.GDforEachObjects1);
gdjs.copyArray(runtimeScene.getObjects("helpButton"), gdjs.TrashPromptCode.GDhelpButtonObjects1);
gdjs.copyArray(runtimeScene.getObjects("if"), gdjs.TrashPromptCode.GDifObjects1);
gdjs.copyArray(runtimeScene.getObjects("pieceBasket"), gdjs.TrashPromptCode.GDpieceBasketObjects1);
gdjs.copyArray(runtimeScene.getObjects("pieceContents"), gdjs.TrashPromptCode.GDpieceContentsObjects1);
gdjs.copyArray(runtimeScene.getObjects("piecePaper"), gdjs.TrashPromptCode.GDpiecePaperObjects1);
gdjs.copyArray(runtimeScene.getObjects("pieceTarget"), gdjs.TrashPromptCode.GDpieceTargetObjects1);
{for(var i = 0, len = gdjs.TrashPromptCode.GDDialogueBoxObjects1.length ;i < len;++i) {
    gdjs.TrashPromptCode.GDDialogueBoxObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.TrashPromptCode.GDNextObjects1.length ;i < len;++i) {
    gdjs.TrashPromptCode.GDNextObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.TrashPromptCode.GDDialogueObjects1.length ;i < len;++i) {
    gdjs.TrashPromptCode.GDDialogueObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.TrashPromptCode.GDCodePromptObjects1.length ;i < len;++i) {
    gdjs.TrashPromptCode.GDCodePromptObjects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.TrashPromptCode.GDInstructionsObjects1.length ;i < len;++i) {
    gdjs.TrashPromptCode.GDInstructionsObjects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.TrashPromptCode.GDforEachObjects1.length ;i < len;++i) {
    gdjs.TrashPromptCode.GDforEachObjects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.TrashPromptCode.GDifObjects1.length ;i < len;++i) {
    gdjs.TrashPromptCode.GDifObjects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.TrashPromptCode.GDbodyObjects1.length ;i < len;++i) {
    gdjs.TrashPromptCode.GDbodyObjects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.TrashPromptCode.GDpieceBasketObjects1.length ;i < len;++i) {
    gdjs.TrashPromptCode.GDpieceBasketObjects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.TrashPromptCode.GDpiecePaperObjects1.length ;i < len;++i) {
    gdjs.TrashPromptCode.GDpiecePaperObjects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.TrashPromptCode.GDpieceTargetObjects1.length ;i < len;++i) {
    gdjs.TrashPromptCode.GDpieceTargetObjects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.TrashPromptCode.GDpieceContentsObjects1.length ;i < len;++i) {
    gdjs.TrashPromptCode.GDpieceContentsObjects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.TrashPromptCode.GDbox1Objects1.length ;i < len;++i) {
    gdjs.TrashPromptCode.GDbox1Objects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.TrashPromptCode.GDbox2Objects1.length ;i < len;++i) {
    gdjs.TrashPromptCode.GDbox2Objects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.TrashPromptCode.GDbox3Objects1.length ;i < len;++i) {
    gdjs.TrashPromptCode.GDbox3Objects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.TrashPromptCode.GDbox4Objects1.length ;i < len;++i) {
    gdjs.TrashPromptCode.GDbox4Objects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.TrashPromptCode.GDhelpButtonObjects1.length ;i < len;++i) {
    gdjs.TrashPromptCode.GDhelpButtonObjects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.TrashPromptCode.GDexitButtonObjects1.length ;i < len;++i) {
    gdjs.TrashPromptCode.GDexitButtonObjects1[i].hide(false);
}
}}

}


};gdjs.TrashPromptCode.mapOfGDgdjs_46TrashPromptCode_46GDNextObjects1Objects = Hashtable.newFrom({"Next": gdjs.TrashPromptCode.GDNextObjects1});gdjs.TrashPromptCode.mapOfGDgdjs_46TrashPromptCode_46GDpieceBasketObjects1Objects = Hashtable.newFrom({"pieceBasket": gdjs.TrashPromptCode.GDpieceBasketObjects1});gdjs.TrashPromptCode.mapOfGDgdjs_46TrashPromptCode_46GDbox1Objects1Objects = Hashtable.newFrom({"box1": gdjs.TrashPromptCode.GDbox1Objects1});gdjs.TrashPromptCode.mapOfGDgdjs_46TrashPromptCode_46GDpiecePaperObjects1Objects = Hashtable.newFrom({"piecePaper": gdjs.TrashPromptCode.GDpiecePaperObjects1});gdjs.TrashPromptCode.mapOfGDgdjs_46TrashPromptCode_46GDbox2Objects1Objects = Hashtable.newFrom({"box2": gdjs.TrashPromptCode.GDbox2Objects1});gdjs.TrashPromptCode.mapOfGDgdjs_46TrashPromptCode_46GDpieceTargetObjects1Objects = Hashtable.newFrom({"pieceTarget": gdjs.TrashPromptCode.GDpieceTargetObjects1});gdjs.TrashPromptCode.mapOfGDgdjs_46TrashPromptCode_46GDbox3Objects1Objects = Hashtable.newFrom({"box3": gdjs.TrashPromptCode.GDbox3Objects1});gdjs.TrashPromptCode.mapOfGDgdjs_46TrashPromptCode_46GDpieceContentsObjects1Objects = Hashtable.newFrom({"pieceContents": gdjs.TrashPromptCode.GDpieceContentsObjects1});gdjs.TrashPromptCode.mapOfGDgdjs_46TrashPromptCode_46GDbox4Objects1Objects = Hashtable.newFrom({"box4": gdjs.TrashPromptCode.GDbox4Objects1});gdjs.TrashPromptCode.mapOfGDgdjs_46TrashPromptCode_46GDDialogueBoxObjects1Objects = Hashtable.newFrom({"DialogueBox": gdjs.TrashPromptCode.GDDialogueBoxObjects1});gdjs.TrashPromptCode.mapOfGDgdjs_46TrashPromptCode_46GDCONFIRMObjects1Objects = Hashtable.newFrom({"CONFIRM": gdjs.TrashPromptCode.GDCONFIRMObjects1});gdjs.TrashPromptCode.eventsList1 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("box1"), gdjs.TrashPromptCode.GDbox1Objects1);
gdjs.copyArray(runtimeScene.getObjects("box2"), gdjs.TrashPromptCode.GDbox2Objects1);
gdjs.copyArray(runtimeScene.getObjects("box3"), gdjs.TrashPromptCode.GDbox3Objects1);
gdjs.copyArray(runtimeScene.getObjects("box4"), gdjs.TrashPromptCode.GDbox4Objects1);
gdjs.copyArray(runtimeScene.getObjects("pieceBasket"), gdjs.TrashPromptCode.GDpieceBasketObjects1);
gdjs.copyArray(runtimeScene.getObjects("pieceContents"), gdjs.TrashPromptCode.GDpieceContentsObjects1);
gdjs.copyArray(runtimeScene.getObjects("piecePaper"), gdjs.TrashPromptCode.GDpiecePaperObjects1);
gdjs.copyArray(runtimeScene.getObjects("pieceTarget"), gdjs.TrashPromptCode.GDpieceTargetObjects1);

gdjs.TrashPromptCode.condition0IsTrue_0.val = false;
gdjs.TrashPromptCode.condition1IsTrue_0.val = false;
gdjs.TrashPromptCode.condition2IsTrue_0.val = false;
gdjs.TrashPromptCode.condition3IsTrue_0.val = false;
{
gdjs.TrashPromptCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.TrashPromptCode.mapOfGDgdjs_46TrashPromptCode_46GDpieceBasketObjects1Objects, gdjs.TrashPromptCode.mapOfGDgdjs_46TrashPromptCode_46GDbox1Objects1Objects, false, runtimeScene, true);
}if ( gdjs.TrashPromptCode.condition0IsTrue_0.val ) {
{
gdjs.TrashPromptCode.condition1IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.TrashPromptCode.mapOfGDgdjs_46TrashPromptCode_46GDpiecePaperObjects1Objects, gdjs.TrashPromptCode.mapOfGDgdjs_46TrashPromptCode_46GDbox2Objects1Objects, false, runtimeScene, true);
}if ( gdjs.TrashPromptCode.condition1IsTrue_0.val ) {
{
gdjs.TrashPromptCode.condition2IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.TrashPromptCode.mapOfGDgdjs_46TrashPromptCode_46GDpieceTargetObjects1Objects, gdjs.TrashPromptCode.mapOfGDgdjs_46TrashPromptCode_46GDbox3Objects1Objects, false, runtimeScene, true);
}if ( gdjs.TrashPromptCode.condition2IsTrue_0.val ) {
{
gdjs.TrashPromptCode.condition3IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.TrashPromptCode.mapOfGDgdjs_46TrashPromptCode_46GDpieceContentsObjects1Objects, gdjs.TrashPromptCode.mapOfGDgdjs_46TrashPromptCode_46GDbox4Objects1Objects, false, runtimeScene, true);
}}
}
}
if (gdjs.TrashPromptCode.condition3IsTrue_0.val) {
/* Reuse gdjs.TrashPromptCode.GDsuccessDialogueObjects1 */
gdjs.TrashPromptCode.GDCONFIRMObjects1.length = 0;

gdjs.TrashPromptCode.GDDialogueBoxObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.TrashPromptCode.mapOfGDgdjs_46TrashPromptCode_46GDDialogueBoxObjects1Objects, 60, 350, "");
}{for(var i = 0, len = gdjs.TrashPromptCode.GDDialogueBoxObjects1.length ;i < len;++i) {
    gdjs.TrashPromptCode.GDDialogueBoxObjects1[i].setScale(gdjs.TrashPromptCode.GDDialogueBoxObjects1[i].getScale() / (2));
}
}{for(var i = 0, len = gdjs.TrashPromptCode.GDDialogueBoxObjects1.length ;i < len;++i) {
    gdjs.TrashPromptCode.GDDialogueBoxObjects1[i].setOpacity(215);
}
}{for(var i = 0, len = gdjs.TrashPromptCode.GDDialogueBoxObjects1.length ;i < len;++i) {
    gdjs.TrashPromptCode.GDDialogueBoxObjects1[i].setZOrder(900);
}
}{for(var i = 0, len = gdjs.TrashPromptCode.GDsuccessDialogueObjects1.length ;i < len;++i) {
    gdjs.TrashPromptCode.GDsuccessDialogueObjects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.TrashPromptCode.GDsuccessDialogueObjects1.length ;i < len;++i) {
    gdjs.TrashPromptCode.GDsuccessDialogueObjects1[i].setZOrder(910);
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.TrashPromptCode.mapOfGDgdjs_46TrashPromptCode_46GDCONFIRMObjects1Objects, 400, 630, "");
}{for(var i = 0, len = gdjs.TrashPromptCode.GDCONFIRMObjects1.length ;i < len;++i) {
    gdjs.TrashPromptCode.GDCONFIRMObjects1[i].setZOrder(920);
}
}}

}


};gdjs.TrashPromptCode.mapOfGDgdjs_46TrashPromptCode_46GDCONFIRMObjects1Objects = Hashtable.newFrom({"CONFIRM": gdjs.TrashPromptCode.GDCONFIRMObjects1});gdjs.TrashPromptCode.eventsList2 = function(runtimeScene) {

{


gdjs.TrashPromptCode.condition0IsTrue_0.val = false;
{
gdjs.TrashPromptCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if (gdjs.TrashPromptCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "TrashSuccess", false);
}}

}


};gdjs.TrashPromptCode.mapOfGDgdjs_46TrashPromptCode_46GDhelpButtonObjects1Objects = Hashtable.newFrom({"helpButton": gdjs.TrashPromptCode.GDhelpButtonObjects1});gdjs.TrashPromptCode.eventsList3 = function(runtimeScene) {

{


gdjs.TrashPromptCode.condition0IsTrue_0.val = false;
{
gdjs.TrashPromptCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if (gdjs.TrashPromptCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("CONFIRM"), gdjs.TrashPromptCode.GDCONFIRMObjects1);
gdjs.copyArray(runtimeScene.getObjects("DialogueBox"), gdjs.TrashPromptCode.GDDialogueBoxObjects1);
/* Reuse gdjs.TrashPromptCode.GDhelpDialogueObjects1 */
{for(var i = 0, len = gdjs.TrashPromptCode.GDDialogueBoxObjects1.length ;i < len;++i) {
    gdjs.TrashPromptCode.GDDialogueBoxObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.TrashPromptCode.GDhelpDialogueObjects1.length ;i < len;++i) {
    gdjs.TrashPromptCode.GDhelpDialogueObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.TrashPromptCode.GDCONFIRMObjects1.length ;i < len;++i) {
    gdjs.TrashPromptCode.GDCONFIRMObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.TrashPromptCode.mapOfGDgdjs_46TrashPromptCode_46GDhelpButtonObjects1Objects = Hashtable.newFrom({"helpButton": gdjs.TrashPromptCode.GDhelpButtonObjects1});gdjs.TrashPromptCode.mapOfGDgdjs_46TrashPromptCode_46GDDialogueBoxObjects1Objects = Hashtable.newFrom({"DialogueBox": gdjs.TrashPromptCode.GDDialogueBoxObjects1});gdjs.TrashPromptCode.mapOfGDgdjs_46TrashPromptCode_46GDCONFIRMObjects1Objects = Hashtable.newFrom({"CONFIRM": gdjs.TrashPromptCode.GDCONFIRMObjects1});gdjs.TrashPromptCode.eventsList4 = function(runtimeScene) {

{


gdjs.TrashPromptCode.condition0IsTrue_0.val = false;
{
gdjs.TrashPromptCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if (gdjs.TrashPromptCode.condition0IsTrue_0.val) {
/* Reuse gdjs.TrashPromptCode.GDhelpDialogueObjects1 */
gdjs.TrashPromptCode.GDCONFIRMObjects1.length = 0;

gdjs.TrashPromptCode.GDDialogueBoxObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.TrashPromptCode.mapOfGDgdjs_46TrashPromptCode_46GDDialogueBoxObjects1Objects, 60, 350, "");
}{for(var i = 0, len = gdjs.TrashPromptCode.GDDialogueBoxObjects1.length ;i < len;++i) {
    gdjs.TrashPromptCode.GDDialogueBoxObjects1[i].setScale(gdjs.TrashPromptCode.GDDialogueBoxObjects1[i].getScale() / (2));
}
}{for(var i = 0, len = gdjs.TrashPromptCode.GDDialogueBoxObjects1.length ;i < len;++i) {
    gdjs.TrashPromptCode.GDDialogueBoxObjects1[i].setOpacity(215);
}
}{for(var i = 0, len = gdjs.TrashPromptCode.GDhelpDialogueObjects1.length ;i < len;++i) {
    gdjs.TrashPromptCode.GDhelpDialogueObjects1[i].hide(false);
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.TrashPromptCode.mapOfGDgdjs_46TrashPromptCode_46GDCONFIRMObjects1Objects, 425, 620, "");
}{for(var i = 0, len = gdjs.TrashPromptCode.GDDialogueBoxObjects1.length ;i < len;++i) {
    gdjs.TrashPromptCode.GDDialogueBoxObjects1[i].setZOrder(900);
}
}{for(var i = 0, len = gdjs.TrashPromptCode.GDhelpDialogueObjects1.length ;i < len;++i) {
    gdjs.TrashPromptCode.GDhelpDialogueObjects1[i].setZOrder(910);
}
}{for(var i = 0, len = gdjs.TrashPromptCode.GDCONFIRMObjects1.length ;i < len;++i) {
    gdjs.TrashPromptCode.GDCONFIRMObjects1[i].setZOrder(920);
}
}}

}


};gdjs.TrashPromptCode.mapOfGDgdjs_46TrashPromptCode_46GDCONFIRMObjects1Objects = Hashtable.newFrom({"CONFIRM": gdjs.TrashPromptCode.GDCONFIRMObjects1});gdjs.TrashPromptCode.eventsList5 = function(runtimeScene) {

{


gdjs.TrashPromptCode.condition0IsTrue_0.val = false;
{
gdjs.TrashPromptCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if (gdjs.TrashPromptCode.condition0IsTrue_0.val) {
/* Reuse gdjs.TrashPromptCode.GDCONFIRMObjects1 */
gdjs.copyArray(runtimeScene.getObjects("DialogueBox"), gdjs.TrashPromptCode.GDDialogueBoxObjects1);
gdjs.copyArray(runtimeScene.getObjects("helpDialogue"), gdjs.TrashPromptCode.GDhelpDialogueObjects1);
{for(var i = 0, len = gdjs.TrashPromptCode.GDDialogueBoxObjects1.length ;i < len;++i) {
    gdjs.TrashPromptCode.GDDialogueBoxObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.TrashPromptCode.GDhelpDialogueObjects1.length ;i < len;++i) {
    gdjs.TrashPromptCode.GDhelpDialogueObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.TrashPromptCode.GDCONFIRMObjects1.length ;i < len;++i) {
    gdjs.TrashPromptCode.GDCONFIRMObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.TrashPromptCode.mapOfGDgdjs_46TrashPromptCode_46GDCONFIRMObjects1Objects = Hashtable.newFrom({"CONFIRM": gdjs.TrashPromptCode.GDCONFIRMObjects1});gdjs.TrashPromptCode.mapOfGDgdjs_46TrashPromptCode_46GDexitButtonObjects1Objects = Hashtable.newFrom({"exitButton": gdjs.TrashPromptCode.GDexitButtonObjects1});gdjs.TrashPromptCode.eventsList6 = function(runtimeScene) {

{


gdjs.TrashPromptCode.condition0IsTrue_0.val = false;
{
gdjs.TrashPromptCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if (gdjs.TrashPromptCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("CONFIRM"), gdjs.TrashPromptCode.GDCONFIRMObjects1);
gdjs.copyArray(runtimeScene.getObjects("DialogueBox"), gdjs.TrashPromptCode.GDDialogueBoxObjects1);
/* Reuse gdjs.TrashPromptCode.GDexitDialogueObjects1 */
{for(var i = 0, len = gdjs.TrashPromptCode.GDDialogueBoxObjects1.length ;i < len;++i) {
    gdjs.TrashPromptCode.GDDialogueBoxObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.TrashPromptCode.GDexitDialogueObjects1.length ;i < len;++i) {
    gdjs.TrashPromptCode.GDexitDialogueObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.TrashPromptCode.GDCONFIRMObjects1.length ;i < len;++i) {
    gdjs.TrashPromptCode.GDCONFIRMObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.TrashPromptCode.mapOfGDgdjs_46TrashPromptCode_46GDexitButtonObjects1Objects = Hashtable.newFrom({"exitButton": gdjs.TrashPromptCode.GDexitButtonObjects1});gdjs.TrashPromptCode.mapOfGDgdjs_46TrashPromptCode_46GDDialogueBoxObjects1Objects = Hashtable.newFrom({"DialogueBox": gdjs.TrashPromptCode.GDDialogueBoxObjects1});gdjs.TrashPromptCode.mapOfGDgdjs_46TrashPromptCode_46GDYESObjects1Objects = Hashtable.newFrom({"YES": gdjs.TrashPromptCode.GDYESObjects1});gdjs.TrashPromptCode.mapOfGDgdjs_46TrashPromptCode_46GDNOObjects1Objects = Hashtable.newFrom({"NO": gdjs.TrashPromptCode.GDNOObjects1});gdjs.TrashPromptCode.eventsList7 = function(runtimeScene) {

{


gdjs.TrashPromptCode.condition0IsTrue_0.val = false;
{
gdjs.TrashPromptCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if (gdjs.TrashPromptCode.condition0IsTrue_0.val) {
/* Reuse gdjs.TrashPromptCode.GDexitDialogueObjects1 */
gdjs.TrashPromptCode.GDDialogueBoxObjects1.length = 0;

gdjs.TrashPromptCode.GDNOObjects1.length = 0;

gdjs.TrashPromptCode.GDYESObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.TrashPromptCode.mapOfGDgdjs_46TrashPromptCode_46GDDialogueBoxObjects1Objects, 60, 350, "");
}{for(var i = 0, len = gdjs.TrashPromptCode.GDDialogueBoxObjects1.length ;i < len;++i) {
    gdjs.TrashPromptCode.GDDialogueBoxObjects1[i].setScale(gdjs.TrashPromptCode.GDDialogueBoxObjects1[i].getScale() / (2));
}
}{for(var i = 0, len = gdjs.TrashPromptCode.GDDialogueBoxObjects1.length ;i < len;++i) {
    gdjs.TrashPromptCode.GDDialogueBoxObjects1[i].setOpacity(215);
}
}{for(var i = 0, len = gdjs.TrashPromptCode.GDexitDialogueObjects1.length ;i < len;++i) {
    gdjs.TrashPromptCode.GDexitDialogueObjects1[i].hide(false);
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.TrashPromptCode.mapOfGDgdjs_46TrashPromptCode_46GDYESObjects1Objects, 355, 600, "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.TrashPromptCode.mapOfGDgdjs_46TrashPromptCode_46GDNOObjects1Objects, 580, 600, "");
}{for(var i = 0, len = gdjs.TrashPromptCode.GDDialogueBoxObjects1.length ;i < len;++i) {
    gdjs.TrashPromptCode.GDDialogueBoxObjects1[i].setZOrder(900);
}
}{for(var i = 0, len = gdjs.TrashPromptCode.GDexitDialogueObjects1.length ;i < len;++i) {
    gdjs.TrashPromptCode.GDexitDialogueObjects1[i].setZOrder(910);
}
}{for(var i = 0, len = gdjs.TrashPromptCode.GDYESObjects1.length ;i < len;++i) {
    gdjs.TrashPromptCode.GDYESObjects1[i].setZOrder(920);
}
}{for(var i = 0, len = gdjs.TrashPromptCode.GDNOObjects1.length ;i < len;++i) {
    gdjs.TrashPromptCode.GDNOObjects1[i].setZOrder(920);
}
}}

}


};gdjs.TrashPromptCode.mapOfGDgdjs_46TrashPromptCode_46GDYESObjects1Objects = Hashtable.newFrom({"YES": gdjs.TrashPromptCode.GDYESObjects1});gdjs.TrashPromptCode.eventsList8 = function(runtimeScene) {

{


gdjs.TrashPromptCode.condition0IsTrue_0.val = false;
{
gdjs.TrashPromptCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if (gdjs.TrashPromptCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.popScene(runtimeScene);
}}

}


};gdjs.TrashPromptCode.mapOfGDgdjs_46TrashPromptCode_46GDNOObjects1Objects = Hashtable.newFrom({"NO": gdjs.TrashPromptCode.GDNOObjects1});gdjs.TrashPromptCode.eventsList9 = function(runtimeScene) {

{


gdjs.TrashPromptCode.condition0IsTrue_0.val = false;
{
gdjs.TrashPromptCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if (gdjs.TrashPromptCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("DialogueBox"), gdjs.TrashPromptCode.GDDialogueBoxObjects1);
/* Reuse gdjs.TrashPromptCode.GDNOObjects1 */
gdjs.copyArray(runtimeScene.getObjects("YES"), gdjs.TrashPromptCode.GDYESObjects1);
gdjs.copyArray(runtimeScene.getObjects("exitDialogue"), gdjs.TrashPromptCode.GDexitDialogueObjects1);
{for(var i = 0, len = gdjs.TrashPromptCode.GDDialogueBoxObjects1.length ;i < len;++i) {
    gdjs.TrashPromptCode.GDDialogueBoxObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.TrashPromptCode.GDexitDialogueObjects1.length ;i < len;++i) {
    gdjs.TrashPromptCode.GDexitDialogueObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.TrashPromptCode.GDYESObjects1.length ;i < len;++i) {
    gdjs.TrashPromptCode.GDYESObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.TrashPromptCode.GDNOObjects1.length ;i < len;++i) {
    gdjs.TrashPromptCode.GDNOObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.TrashPromptCode.mapOfGDgdjs_46TrashPromptCode_46GDYESObjects1Objects = Hashtable.newFrom({"YES": gdjs.TrashPromptCode.GDYESObjects1});gdjs.TrashPromptCode.mapOfGDgdjs_46TrashPromptCode_46GDNOObjects1Objects = Hashtable.newFrom({"NO": gdjs.TrashPromptCode.GDNOObjects1});gdjs.TrashPromptCode.eventsList10 = function(runtimeScene) {

{


gdjs.TrashPromptCode.condition0IsTrue_0.val = false;
gdjs.TrashPromptCode.condition1IsTrue_0.val = false;
{
gdjs.TrashPromptCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)) < 1800;
}if ( gdjs.TrashPromptCode.condition0IsTrue_0.val ) {
{
gdjs.TrashPromptCode.condition1IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)) > 540;
}}
if (gdjs.TrashPromptCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("TimerMinutes"), gdjs.TrashPromptCode.GDTimerMinutesObjects2);
{for(var i = 0, len = gdjs.TrashPromptCode.GDTimerMinutesObjects2.length ;i < len;++i) {
    gdjs.TrashPromptCode.GDTimerMinutesObjects2[i].setString(gdjs.evtTools.common.toString(Math.floor(gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)) / 60)) + ":");
}
}}

}


{


gdjs.TrashPromptCode.condition0IsTrue_0.val = false;
{
gdjs.TrashPromptCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)) < 600;
}if (gdjs.TrashPromptCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("TimerMinutes"), gdjs.TrashPromptCode.GDTimerMinutesObjects2);
{for(var i = 0, len = gdjs.TrashPromptCode.GDTimerMinutesObjects2.length ;i < len;++i) {
    gdjs.TrashPromptCode.GDTimerMinutesObjects2[i].setString("0" + gdjs.evtTools.common.toString(Math.floor(gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)) / 60)) + ":");
}
}}

}


{


gdjs.TrashPromptCode.condition0IsTrue_0.val = false;
{
gdjs.TrashPromptCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)) < 1800;
}if (gdjs.TrashPromptCode.condition0IsTrue_0.val) {
{runtimeScene.getGame().getVariables().getFromIndex(4).sub(gdjs.evtTools.runtimeScene.getElapsedTimeInSeconds(runtimeScene));
}}

}


{


gdjs.TrashPromptCode.condition0IsTrue_0.val = false;
gdjs.TrashPromptCode.condition1IsTrue_0.val = false;
{
gdjs.TrashPromptCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4)) < 60;
}if ( gdjs.TrashPromptCode.condition0IsTrue_0.val ) {
{
gdjs.TrashPromptCode.condition1IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4)) > 9;
}}
if (gdjs.TrashPromptCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("TimerSeconds"), gdjs.TrashPromptCode.GDTimerSecondsObjects2);
{for(var i = 0, len = gdjs.TrashPromptCode.GDTimerSecondsObjects2.length ;i < len;++i) {
    gdjs.TrashPromptCode.GDTimerSecondsObjects2[i].setString(gdjs.evtTools.common.toString(Math.floor(gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4)))));
}
}}

}


{


gdjs.TrashPromptCode.condition0IsTrue_0.val = false;
{
gdjs.TrashPromptCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4)) < 10;
}if (gdjs.TrashPromptCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("TimerSeconds"), gdjs.TrashPromptCode.GDTimerSecondsObjects2);
{for(var i = 0, len = gdjs.TrashPromptCode.GDTimerSecondsObjects2.length ;i < len;++i) {
    gdjs.TrashPromptCode.GDTimerSecondsObjects2[i].setString("0" + gdjs.evtTools.common.toString(Math.floor(gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4)))));
}
}}

}


{


gdjs.TrashPromptCode.condition0IsTrue_0.val = false;
{
gdjs.TrashPromptCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)) == 0;
}if (gdjs.TrashPromptCode.condition0IsTrue_0.val) {
{runtimeScene.getGame().getVariables().getFromIndex(4).setNumber(59);
}}

}


{


gdjs.TrashPromptCode.condition0IsTrue_0.val = false;
{
gdjs.TrashPromptCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)) <= 0;
}if (gdjs.TrashPromptCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "GameOver", false);
}}

}


};gdjs.TrashPromptCode.eventsList11 = function(runtimeScene) {

{


{
{runtimeScene.getGame().getVariables().getFromIndex(3).sub(gdjs.evtTools.runtimeScene.getElapsedTimeInSeconds(runtimeScene));
}
{ //Subevents
gdjs.TrashPromptCode.eventsList10(runtimeScene);} //End of subevents
}

}


};gdjs.TrashPromptCode.eventsList12 = function(runtimeScene) {

{



}


{


gdjs.TrashPromptCode.condition0IsTrue_0.val = false;
{
gdjs.TrashPromptCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.TrashPromptCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("CodePrompt"), gdjs.TrashPromptCode.GDCodePromptObjects1);
gdjs.copyArray(runtimeScene.getObjects("Instructions"), gdjs.TrashPromptCode.GDInstructionsObjects1);
gdjs.copyArray(runtimeScene.getObjects("body"), gdjs.TrashPromptCode.GDbodyObjects1);
gdjs.copyArray(runtimeScene.getObjects("box1"), gdjs.TrashPromptCode.GDbox1Objects1);
gdjs.copyArray(runtimeScene.getObjects("box2"), gdjs.TrashPromptCode.GDbox2Objects1);
gdjs.copyArray(runtimeScene.getObjects("box3"), gdjs.TrashPromptCode.GDbox3Objects1);
gdjs.copyArray(runtimeScene.getObjects("box4"), gdjs.TrashPromptCode.GDbox4Objects1);
gdjs.copyArray(runtimeScene.getObjects("exitButton"), gdjs.TrashPromptCode.GDexitButtonObjects1);
gdjs.copyArray(runtimeScene.getObjects("exitDialogue"), gdjs.TrashPromptCode.GDexitDialogueObjects1);
gdjs.copyArray(runtimeScene.getObjects("forEach"), gdjs.TrashPromptCode.GDforEachObjects1);
gdjs.copyArray(runtimeScene.getObjects("helpButton"), gdjs.TrashPromptCode.GDhelpButtonObjects1);
gdjs.copyArray(runtimeScene.getObjects("helpDialogue"), gdjs.TrashPromptCode.GDhelpDialogueObjects1);
gdjs.copyArray(runtimeScene.getObjects("if"), gdjs.TrashPromptCode.GDifObjects1);
gdjs.copyArray(runtimeScene.getObjects("pieceBasket"), gdjs.TrashPromptCode.GDpieceBasketObjects1);
gdjs.copyArray(runtimeScene.getObjects("pieceContents"), gdjs.TrashPromptCode.GDpieceContentsObjects1);
gdjs.copyArray(runtimeScene.getObjects("piecePaper"), gdjs.TrashPromptCode.GDpiecePaperObjects1);
gdjs.copyArray(runtimeScene.getObjects("pieceTarget"), gdjs.TrashPromptCode.GDpieceTargetObjects1);
gdjs.copyArray(runtimeScene.getObjects("successDialogue"), gdjs.TrashPromptCode.GDsuccessDialogueObjects1);
gdjs.TrashPromptCode.GDDialogueBoxObjects1.length = 0;

gdjs.TrashPromptCode.GDNextObjects1.length = 0;

{for(var i = 0, len = gdjs.TrashPromptCode.GDhelpDialogueObjects1.length ;i < len;++i) {
    gdjs.TrashPromptCode.GDhelpDialogueObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.TrashPromptCode.GDexitDialogueObjects1.length ;i < len;++i) {
    gdjs.TrashPromptCode.GDexitDialogueObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.TrashPromptCode.GDCodePromptObjects1.length ;i < len;++i) {
    gdjs.TrashPromptCode.GDCodePromptObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.TrashPromptCode.GDInstructionsObjects1.length ;i < len;++i) {
    gdjs.TrashPromptCode.GDInstructionsObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.TrashPromptCode.GDforEachObjects1.length ;i < len;++i) {
    gdjs.TrashPromptCode.GDforEachObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.TrashPromptCode.GDifObjects1.length ;i < len;++i) {
    gdjs.TrashPromptCode.GDifObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.TrashPromptCode.GDbodyObjects1.length ;i < len;++i) {
    gdjs.TrashPromptCode.GDbodyObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.TrashPromptCode.GDpieceBasketObjects1.length ;i < len;++i) {
    gdjs.TrashPromptCode.GDpieceBasketObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.TrashPromptCode.GDpiecePaperObjects1.length ;i < len;++i) {
    gdjs.TrashPromptCode.GDpiecePaperObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.TrashPromptCode.GDpieceTargetObjects1.length ;i < len;++i) {
    gdjs.TrashPromptCode.GDpieceTargetObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.TrashPromptCode.GDpieceContentsObjects1.length ;i < len;++i) {
    gdjs.TrashPromptCode.GDpieceContentsObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.TrashPromptCode.GDbox1Objects1.length ;i < len;++i) {
    gdjs.TrashPromptCode.GDbox1Objects1[i].hide();
}
}{for(var i = 0, len = gdjs.TrashPromptCode.GDbox2Objects1.length ;i < len;++i) {
    gdjs.TrashPromptCode.GDbox2Objects1[i].hide();
}
}{for(var i = 0, len = gdjs.TrashPromptCode.GDbox3Objects1.length ;i < len;++i) {
    gdjs.TrashPromptCode.GDbox3Objects1[i].hide();
}
}{for(var i = 0, len = gdjs.TrashPromptCode.GDbox4Objects1.length ;i < len;++i) {
    gdjs.TrashPromptCode.GDbox4Objects1[i].hide();
}
}{for(var i = 0, len = gdjs.TrashPromptCode.GDhelpButtonObjects1.length ;i < len;++i) {
    gdjs.TrashPromptCode.GDhelpButtonObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.TrashPromptCode.GDexitButtonObjects1.length ;i < len;++i) {
    gdjs.TrashPromptCode.GDexitButtonObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.TrashPromptCode.GDsuccessDialogueObjects1.length ;i < len;++i) {
    gdjs.TrashPromptCode.GDsuccessDialogueObjects1[i].hide();
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.TrashPromptCode.mapOfGDgdjs_46TrashPromptCode_46GDDialogueBoxObjects1Objects, 60, 576, "");
}{for(var i = 0, len = gdjs.TrashPromptCode.GDDialogueBoxObjects1.length ;i < len;++i) {
    gdjs.TrashPromptCode.GDDialogueBoxObjects1[i].setScale(gdjs.TrashPromptCode.GDDialogueBoxObjects1[i].getScale() / (2));
}
}{for(var i = 0, len = gdjs.TrashPromptCode.GDDialogueBoxObjects1.length ;i < len;++i) {
    gdjs.TrashPromptCode.GDDialogueBoxObjects1[i].setOpacity(215);
}
}{for(var i = 0, len = gdjs.TrashPromptCode.GDDialogueBoxObjects1.length ;i < len;++i) {
    gdjs.TrashPromptCode.GDDialogueBoxObjects1[i].setZOrder(20);
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.TrashPromptCode.mapOfGDgdjs_46TrashPromptCode_46GDNextObjects1Objects, 739, 881, "");
}{for(var i = 0, len = gdjs.TrashPromptCode.GDNextObjects1.length ;i < len;++i) {
    gdjs.TrashPromptCode.GDNextObjects1[i].setZOrder(25);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Next"), gdjs.TrashPromptCode.GDNextObjects1);

gdjs.TrashPromptCode.condition0IsTrue_0.val = false;
{
gdjs.TrashPromptCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.TrashPromptCode.mapOfGDgdjs_46TrashPromptCode_46GDNextObjects1Objects, runtimeScene, true, false);
}if (gdjs.TrashPromptCode.condition0IsTrue_0.val) {
/* Reuse gdjs.TrashPromptCode.GDNextObjects1 */
{for(var i = 0, len = gdjs.TrashPromptCode.GDNextObjects1.length ;i < len;++i) {
    gdjs.TrashPromptCode.GDNextObjects1[i].setColor("255;255;255");
}
}
{ //Subevents
gdjs.TrashPromptCode.eventsList0(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Next"), gdjs.TrashPromptCode.GDNextObjects1);

gdjs.TrashPromptCode.condition0IsTrue_0.val = false;
{
gdjs.TrashPromptCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.TrashPromptCode.mapOfGDgdjs_46TrashPromptCode_46GDNextObjects1Objects, runtimeScene, true, true);
}if (gdjs.TrashPromptCode.condition0IsTrue_0.val) {
/* Reuse gdjs.TrashPromptCode.GDNextObjects1 */
{for(var i = 0, len = gdjs.TrashPromptCode.GDNextObjects1.length ;i < len;++i) {
    gdjs.TrashPromptCode.GDNextObjects1[i].setColor("155;155;155");
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("successDialogue"), gdjs.TrashPromptCode.GDsuccessDialogueObjects1);

gdjs.TrashPromptCode.condition0IsTrue_0.val = false;
gdjs.TrashPromptCode.condition1IsTrue_0.val = false;
{
gdjs.TrashPromptCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if ( gdjs.TrashPromptCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.TrashPromptCode.GDsuccessDialogueObjects1.length;i<l;++i) {
    if ( !(gdjs.TrashPromptCode.GDsuccessDialogueObjects1[i].isVisible()) ) {
        gdjs.TrashPromptCode.condition1IsTrue_0.val = true;
        gdjs.TrashPromptCode.GDsuccessDialogueObjects1[k] = gdjs.TrashPromptCode.GDsuccessDialogueObjects1[i];
        ++k;
    }
}
gdjs.TrashPromptCode.GDsuccessDialogueObjects1.length = k;}}
if (gdjs.TrashPromptCode.condition1IsTrue_0.val) {

{ //Subevents
gdjs.TrashPromptCode.eventsList1(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("CONFIRM"), gdjs.TrashPromptCode.GDCONFIRMObjects1);
gdjs.copyArray(runtimeScene.getObjects("helpDialogue"), gdjs.TrashPromptCode.GDhelpDialogueObjects1);

gdjs.TrashPromptCode.condition0IsTrue_0.val = false;
gdjs.TrashPromptCode.condition1IsTrue_0.val = false;
{
gdjs.TrashPromptCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.TrashPromptCode.mapOfGDgdjs_46TrashPromptCode_46GDCONFIRMObjects1Objects, runtimeScene, true, false);
}if ( gdjs.TrashPromptCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.TrashPromptCode.GDhelpDialogueObjects1.length;i<l;++i) {
    if ( !(gdjs.TrashPromptCode.GDhelpDialogueObjects1[i].isVisible()) ) {
        gdjs.TrashPromptCode.condition1IsTrue_0.val = true;
        gdjs.TrashPromptCode.GDhelpDialogueObjects1[k] = gdjs.TrashPromptCode.GDhelpDialogueObjects1[i];
        ++k;
    }
}
gdjs.TrashPromptCode.GDhelpDialogueObjects1.length = k;}}
if (gdjs.TrashPromptCode.condition1IsTrue_0.val) {

{ //Subevents
gdjs.TrashPromptCode.eventsList2(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("helpButton"), gdjs.TrashPromptCode.GDhelpButtonObjects1);
gdjs.copyArray(runtimeScene.getObjects("helpDialogue"), gdjs.TrashPromptCode.GDhelpDialogueObjects1);

gdjs.TrashPromptCode.condition0IsTrue_0.val = false;
gdjs.TrashPromptCode.condition1IsTrue_0.val = false;
{
gdjs.TrashPromptCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.TrashPromptCode.mapOfGDgdjs_46TrashPromptCode_46GDhelpButtonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.TrashPromptCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.TrashPromptCode.GDhelpDialogueObjects1.length;i<l;++i) {
    if ( gdjs.TrashPromptCode.GDhelpDialogueObjects1[i].isVisible() ) {
        gdjs.TrashPromptCode.condition1IsTrue_0.val = true;
        gdjs.TrashPromptCode.GDhelpDialogueObjects1[k] = gdjs.TrashPromptCode.GDhelpDialogueObjects1[i];
        ++k;
    }
}
gdjs.TrashPromptCode.GDhelpDialogueObjects1.length = k;}}
if (gdjs.TrashPromptCode.condition1IsTrue_0.val) {

{ //Subevents
gdjs.TrashPromptCode.eventsList3(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("helpButton"), gdjs.TrashPromptCode.GDhelpButtonObjects1);
gdjs.copyArray(runtimeScene.getObjects("helpDialogue"), gdjs.TrashPromptCode.GDhelpDialogueObjects1);
gdjs.copyArray(runtimeScene.getObjects("successDialogue"), gdjs.TrashPromptCode.GDsuccessDialogueObjects1);

gdjs.TrashPromptCode.condition0IsTrue_0.val = false;
gdjs.TrashPromptCode.condition1IsTrue_0.val = false;
gdjs.TrashPromptCode.condition2IsTrue_0.val = false;
{
gdjs.TrashPromptCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.TrashPromptCode.mapOfGDgdjs_46TrashPromptCode_46GDhelpButtonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.TrashPromptCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.TrashPromptCode.GDhelpDialogueObjects1.length;i<l;++i) {
    if ( !(gdjs.TrashPromptCode.GDhelpDialogueObjects1[i].isVisible()) ) {
        gdjs.TrashPromptCode.condition1IsTrue_0.val = true;
        gdjs.TrashPromptCode.GDhelpDialogueObjects1[k] = gdjs.TrashPromptCode.GDhelpDialogueObjects1[i];
        ++k;
    }
}
gdjs.TrashPromptCode.GDhelpDialogueObjects1.length = k;}if ( gdjs.TrashPromptCode.condition1IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.TrashPromptCode.GDsuccessDialogueObjects1.length;i<l;++i) {
    if ( !(gdjs.TrashPromptCode.GDsuccessDialogueObjects1[i].isVisible()) ) {
        gdjs.TrashPromptCode.condition2IsTrue_0.val = true;
        gdjs.TrashPromptCode.GDsuccessDialogueObjects1[k] = gdjs.TrashPromptCode.GDsuccessDialogueObjects1[i];
        ++k;
    }
}
gdjs.TrashPromptCode.GDsuccessDialogueObjects1.length = k;}}
}
if (gdjs.TrashPromptCode.condition2IsTrue_0.val) {

{ //Subevents
gdjs.TrashPromptCode.eventsList4(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("CONFIRM"), gdjs.TrashPromptCode.GDCONFIRMObjects1);

gdjs.TrashPromptCode.condition0IsTrue_0.val = false;
{
gdjs.TrashPromptCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.TrashPromptCode.mapOfGDgdjs_46TrashPromptCode_46GDCONFIRMObjects1Objects, runtimeScene, true, false);
}if (gdjs.TrashPromptCode.condition0IsTrue_0.val) {
/* Reuse gdjs.TrashPromptCode.GDCONFIRMObjects1 */
{for(var i = 0, len = gdjs.TrashPromptCode.GDCONFIRMObjects1.length ;i < len;++i) {
    gdjs.TrashPromptCode.GDCONFIRMObjects1[i].setColor("255;255;255");
}
}
{ //Subevents
gdjs.TrashPromptCode.eventsList5(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("CONFIRM"), gdjs.TrashPromptCode.GDCONFIRMObjects1);

gdjs.TrashPromptCode.condition0IsTrue_0.val = false;
{
gdjs.TrashPromptCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.TrashPromptCode.mapOfGDgdjs_46TrashPromptCode_46GDCONFIRMObjects1Objects, runtimeScene, true, true);
}if (gdjs.TrashPromptCode.condition0IsTrue_0.val) {
/* Reuse gdjs.TrashPromptCode.GDCONFIRMObjects1 */
{for(var i = 0, len = gdjs.TrashPromptCode.GDCONFIRMObjects1.length ;i < len;++i) {
    gdjs.TrashPromptCode.GDCONFIRMObjects1[i].setColor("155;155;155");
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("exitButton"), gdjs.TrashPromptCode.GDexitButtonObjects1);
gdjs.copyArray(runtimeScene.getObjects("exitDialogue"), gdjs.TrashPromptCode.GDexitDialogueObjects1);

gdjs.TrashPromptCode.condition0IsTrue_0.val = false;
gdjs.TrashPromptCode.condition1IsTrue_0.val = false;
{
gdjs.TrashPromptCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.TrashPromptCode.mapOfGDgdjs_46TrashPromptCode_46GDexitButtonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.TrashPromptCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.TrashPromptCode.GDexitDialogueObjects1.length;i<l;++i) {
    if ( gdjs.TrashPromptCode.GDexitDialogueObjects1[i].isVisible() ) {
        gdjs.TrashPromptCode.condition1IsTrue_0.val = true;
        gdjs.TrashPromptCode.GDexitDialogueObjects1[k] = gdjs.TrashPromptCode.GDexitDialogueObjects1[i];
        ++k;
    }
}
gdjs.TrashPromptCode.GDexitDialogueObjects1.length = k;}}
if (gdjs.TrashPromptCode.condition1IsTrue_0.val) {

{ //Subevents
gdjs.TrashPromptCode.eventsList6(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("exitButton"), gdjs.TrashPromptCode.GDexitButtonObjects1);
gdjs.copyArray(runtimeScene.getObjects("exitDialogue"), gdjs.TrashPromptCode.GDexitDialogueObjects1);
gdjs.copyArray(runtimeScene.getObjects("successDialogue"), gdjs.TrashPromptCode.GDsuccessDialogueObjects1);

gdjs.TrashPromptCode.condition0IsTrue_0.val = false;
gdjs.TrashPromptCode.condition1IsTrue_0.val = false;
gdjs.TrashPromptCode.condition2IsTrue_0.val = false;
{
gdjs.TrashPromptCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.TrashPromptCode.mapOfGDgdjs_46TrashPromptCode_46GDexitButtonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.TrashPromptCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.TrashPromptCode.GDexitDialogueObjects1.length;i<l;++i) {
    if ( !(gdjs.TrashPromptCode.GDexitDialogueObjects1[i].isVisible()) ) {
        gdjs.TrashPromptCode.condition1IsTrue_0.val = true;
        gdjs.TrashPromptCode.GDexitDialogueObjects1[k] = gdjs.TrashPromptCode.GDexitDialogueObjects1[i];
        ++k;
    }
}
gdjs.TrashPromptCode.GDexitDialogueObjects1.length = k;}if ( gdjs.TrashPromptCode.condition1IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.TrashPromptCode.GDsuccessDialogueObjects1.length;i<l;++i) {
    if ( !(gdjs.TrashPromptCode.GDsuccessDialogueObjects1[i].isVisible()) ) {
        gdjs.TrashPromptCode.condition2IsTrue_0.val = true;
        gdjs.TrashPromptCode.GDsuccessDialogueObjects1[k] = gdjs.TrashPromptCode.GDsuccessDialogueObjects1[i];
        ++k;
    }
}
gdjs.TrashPromptCode.GDsuccessDialogueObjects1.length = k;}}
}
if (gdjs.TrashPromptCode.condition2IsTrue_0.val) {

{ //Subevents
gdjs.TrashPromptCode.eventsList7(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("YES"), gdjs.TrashPromptCode.GDYESObjects1);

gdjs.TrashPromptCode.condition0IsTrue_0.val = false;
{
gdjs.TrashPromptCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.TrashPromptCode.mapOfGDgdjs_46TrashPromptCode_46GDYESObjects1Objects, runtimeScene, true, false);
}if (gdjs.TrashPromptCode.condition0IsTrue_0.val) {
/* Reuse gdjs.TrashPromptCode.GDYESObjects1 */
{for(var i = 0, len = gdjs.TrashPromptCode.GDYESObjects1.length ;i < len;++i) {
    gdjs.TrashPromptCode.GDYESObjects1[i].setColor("255;255;255");
}
}
{ //Subevents
gdjs.TrashPromptCode.eventsList8(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("NO"), gdjs.TrashPromptCode.GDNOObjects1);

gdjs.TrashPromptCode.condition0IsTrue_0.val = false;
{
gdjs.TrashPromptCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.TrashPromptCode.mapOfGDgdjs_46TrashPromptCode_46GDNOObjects1Objects, runtimeScene, true, false);
}if (gdjs.TrashPromptCode.condition0IsTrue_0.val) {
/* Reuse gdjs.TrashPromptCode.GDNOObjects1 */
{for(var i = 0, len = gdjs.TrashPromptCode.GDNOObjects1.length ;i < len;++i) {
    gdjs.TrashPromptCode.GDNOObjects1[i].setColor("255;255;255");
}
}
{ //Subevents
gdjs.TrashPromptCode.eventsList9(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("YES"), gdjs.TrashPromptCode.GDYESObjects1);

gdjs.TrashPromptCode.condition0IsTrue_0.val = false;
{
gdjs.TrashPromptCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.TrashPromptCode.mapOfGDgdjs_46TrashPromptCode_46GDYESObjects1Objects, runtimeScene, true, true);
}if (gdjs.TrashPromptCode.condition0IsTrue_0.val) {
/* Reuse gdjs.TrashPromptCode.GDYESObjects1 */
{for(var i = 0, len = gdjs.TrashPromptCode.GDYESObjects1.length ;i < len;++i) {
    gdjs.TrashPromptCode.GDYESObjects1[i].setColor("155;155;155");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("NO"), gdjs.TrashPromptCode.GDNOObjects1);

gdjs.TrashPromptCode.condition0IsTrue_0.val = false;
{
gdjs.TrashPromptCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.TrashPromptCode.mapOfGDgdjs_46TrashPromptCode_46GDNOObjects1Objects, runtimeScene, true, true);
}if (gdjs.TrashPromptCode.condition0IsTrue_0.val) {
/* Reuse gdjs.TrashPromptCode.GDNOObjects1 */
{for(var i = 0, len = gdjs.TrashPromptCode.GDNOObjects1.length ;i < len;++i) {
    gdjs.TrashPromptCode.GDNOObjects1[i].setColor("155;155;155");
}
}}

}


{


gdjs.TrashPromptCode.eventsList11(runtimeScene);
}


};

gdjs.TrashPromptCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.TrashPromptCode.GDBackgroundObjects1.length = 0;
gdjs.TrashPromptCode.GDBackgroundObjects2.length = 0;
gdjs.TrashPromptCode.GDBackgroundObjects3.length = 0;
gdjs.TrashPromptCode.GDCodePromptObjects1.length = 0;
gdjs.TrashPromptCode.GDCodePromptObjects2.length = 0;
gdjs.TrashPromptCode.GDCodePromptObjects3.length = 0;
gdjs.TrashPromptCode.GDInstructionsObjects1.length = 0;
gdjs.TrashPromptCode.GDInstructionsObjects2.length = 0;
gdjs.TrashPromptCode.GDInstructionsObjects3.length = 0;
gdjs.TrashPromptCode.GDforEachObjects1.length = 0;
gdjs.TrashPromptCode.GDforEachObjects2.length = 0;
gdjs.TrashPromptCode.GDforEachObjects3.length = 0;
gdjs.TrashPromptCode.GDifObjects1.length = 0;
gdjs.TrashPromptCode.GDifObjects2.length = 0;
gdjs.TrashPromptCode.GDifObjects3.length = 0;
gdjs.TrashPromptCode.GDbodyObjects1.length = 0;
gdjs.TrashPromptCode.GDbodyObjects2.length = 0;
gdjs.TrashPromptCode.GDbodyObjects3.length = 0;
gdjs.TrashPromptCode.GDpieceBasketObjects1.length = 0;
gdjs.TrashPromptCode.GDpieceBasketObjects2.length = 0;
gdjs.TrashPromptCode.GDpieceBasketObjects3.length = 0;
gdjs.TrashPromptCode.GDpiecePaperObjects1.length = 0;
gdjs.TrashPromptCode.GDpiecePaperObjects2.length = 0;
gdjs.TrashPromptCode.GDpiecePaperObjects3.length = 0;
gdjs.TrashPromptCode.GDpieceTargetObjects1.length = 0;
gdjs.TrashPromptCode.GDpieceTargetObjects2.length = 0;
gdjs.TrashPromptCode.GDpieceTargetObjects3.length = 0;
gdjs.TrashPromptCode.GDpieceContentsObjects1.length = 0;
gdjs.TrashPromptCode.GDpieceContentsObjects2.length = 0;
gdjs.TrashPromptCode.GDpieceContentsObjects3.length = 0;
gdjs.TrashPromptCode.GDbox1Objects1.length = 0;
gdjs.TrashPromptCode.GDbox1Objects2.length = 0;
gdjs.TrashPromptCode.GDbox1Objects3.length = 0;
gdjs.TrashPromptCode.GDbox2Objects1.length = 0;
gdjs.TrashPromptCode.GDbox2Objects2.length = 0;
gdjs.TrashPromptCode.GDbox2Objects3.length = 0;
gdjs.TrashPromptCode.GDbox3Objects1.length = 0;
gdjs.TrashPromptCode.GDbox3Objects2.length = 0;
gdjs.TrashPromptCode.GDbox3Objects3.length = 0;
gdjs.TrashPromptCode.GDbox4Objects1.length = 0;
gdjs.TrashPromptCode.GDbox4Objects2.length = 0;
gdjs.TrashPromptCode.GDbox4Objects3.length = 0;
gdjs.TrashPromptCode.GDSuccessObjects1.length = 0;
gdjs.TrashPromptCode.GDSuccessObjects2.length = 0;
gdjs.TrashPromptCode.GDSuccessObjects3.length = 0;
gdjs.TrashPromptCode.GDDialogueBoxObjects1.length = 0;
gdjs.TrashPromptCode.GDDialogueBoxObjects2.length = 0;
gdjs.TrashPromptCode.GDDialogueBoxObjects3.length = 0;
gdjs.TrashPromptCode.GDhelpDialogueObjects1.length = 0;
gdjs.TrashPromptCode.GDhelpDialogueObjects2.length = 0;
gdjs.TrashPromptCode.GDhelpDialogueObjects3.length = 0;
gdjs.TrashPromptCode.GDexitButtonObjects1.length = 0;
gdjs.TrashPromptCode.GDexitButtonObjects2.length = 0;
gdjs.TrashPromptCode.GDexitButtonObjects3.length = 0;
gdjs.TrashPromptCode.GDhelpButtonObjects1.length = 0;
gdjs.TrashPromptCode.GDhelpButtonObjects2.length = 0;
gdjs.TrashPromptCode.GDhelpButtonObjects3.length = 0;
gdjs.TrashPromptCode.GDexitDialogueObjects1.length = 0;
gdjs.TrashPromptCode.GDexitDialogueObjects2.length = 0;
gdjs.TrashPromptCode.GDexitDialogueObjects3.length = 0;
gdjs.TrashPromptCode.GDYESObjects1.length = 0;
gdjs.TrashPromptCode.GDYESObjects2.length = 0;
gdjs.TrashPromptCode.GDYESObjects3.length = 0;
gdjs.TrashPromptCode.GDNOObjects1.length = 0;
gdjs.TrashPromptCode.GDNOObjects2.length = 0;
gdjs.TrashPromptCode.GDNOObjects3.length = 0;
gdjs.TrashPromptCode.GDCONFIRMObjects1.length = 0;
gdjs.TrashPromptCode.GDCONFIRMObjects2.length = 0;
gdjs.TrashPromptCode.GDCONFIRMObjects3.length = 0;
gdjs.TrashPromptCode.GDDialogueObjects1.length = 0;
gdjs.TrashPromptCode.GDDialogueObjects2.length = 0;
gdjs.TrashPromptCode.GDDialogueObjects3.length = 0;
gdjs.TrashPromptCode.GDNextObjects1.length = 0;
gdjs.TrashPromptCode.GDNextObjects2.length = 0;
gdjs.TrashPromptCode.GDNextObjects3.length = 0;
gdjs.TrashPromptCode.GDsuccessDialogueObjects1.length = 0;
gdjs.TrashPromptCode.GDsuccessDialogueObjects2.length = 0;
gdjs.TrashPromptCode.GDsuccessDialogueObjects3.length = 0;
gdjs.TrashPromptCode.GDTimerMinutesObjects1.length = 0;
gdjs.TrashPromptCode.GDTimerMinutesObjects2.length = 0;
gdjs.TrashPromptCode.GDTimerMinutesObjects3.length = 0;
gdjs.TrashPromptCode.GDTimerSecondsObjects1.length = 0;
gdjs.TrashPromptCode.GDTimerSecondsObjects2.length = 0;
gdjs.TrashPromptCode.GDTimerSecondsObjects3.length = 0;

gdjs.TrashPromptCode.eventsList12(runtimeScene);
return;

}

gdjs['TrashPromptCode'] = gdjs.TrashPromptCode;
