gdjs.DeskPromptCode = {};
gdjs.DeskPromptCode.GDBackgroundObjects1= [];
gdjs.DeskPromptCode.GDBackgroundObjects2= [];
gdjs.DeskPromptCode.GDBackgroundObjects3= [];
gdjs.DeskPromptCode.GDCodePromptObjects1= [];
gdjs.DeskPromptCode.GDCodePromptObjects2= [];
gdjs.DeskPromptCode.GDCodePromptObjects3= [];
gdjs.DeskPromptCode.GDInstructionsObjects1= [];
gdjs.DeskPromptCode.GDInstructionsObjects2= [];
gdjs.DeskPromptCode.GDInstructionsObjects3= [];
gdjs.DeskPromptCode.GDforObjects1= [];
gdjs.DeskPromptCode.GDforObjects2= [];
gdjs.DeskPromptCode.GDforObjects3= [];
gdjs.DeskPromptCode.GDifObjects1= [];
gdjs.DeskPromptCode.GDifObjects2= [];
gdjs.DeskPromptCode.GDifObjects3= [];
gdjs.DeskPromptCode.GDbodyObjects1= [];
gdjs.DeskPromptCode.GDbodyObjects2= [];
gdjs.DeskPromptCode.GDbodyObjects3= [];
gdjs.DeskPromptCode.GDpieceStartObjects1= [];
gdjs.DeskPromptCode.GDpieceStartObjects2= [];
gdjs.DeskPromptCode.GDpieceStartObjects3= [];
gdjs.DeskPromptCode.GDpieceEndObjects1= [];
gdjs.DeskPromptCode.GDpieceEndObjects2= [];
gdjs.DeskPromptCode.GDpieceEndObjects3= [];
gdjs.DeskPromptCode.GDpieceClueObjects1= [];
gdjs.DeskPromptCode.GDpieceClueObjects2= [];
gdjs.DeskPromptCode.GDpieceClueObjects3= [];
gdjs.DeskPromptCode.GDpieceBreakObjects1= [];
gdjs.DeskPromptCode.GDpieceBreakObjects2= [];
gdjs.DeskPromptCode.GDpieceBreakObjects3= [];
gdjs.DeskPromptCode.GDbox1Objects1= [];
gdjs.DeskPromptCode.GDbox1Objects2= [];
gdjs.DeskPromptCode.GDbox1Objects3= [];
gdjs.DeskPromptCode.GDbox2Objects1= [];
gdjs.DeskPromptCode.GDbox2Objects2= [];
gdjs.DeskPromptCode.GDbox2Objects3= [];
gdjs.DeskPromptCode.GDbox3Objects1= [];
gdjs.DeskPromptCode.GDbox3Objects2= [];
gdjs.DeskPromptCode.GDbox3Objects3= [];
gdjs.DeskPromptCode.GDbox4Objects1= [];
gdjs.DeskPromptCode.GDbox4Objects2= [];
gdjs.DeskPromptCode.GDbox4Objects3= [];
gdjs.DeskPromptCode.GDSuccessObjects1= [];
gdjs.DeskPromptCode.GDSuccessObjects2= [];
gdjs.DeskPromptCode.GDSuccessObjects3= [];
gdjs.DeskPromptCode.GDDialogueBoxObjects1= [];
gdjs.DeskPromptCode.GDDialogueBoxObjects2= [];
gdjs.DeskPromptCode.GDDialogueBoxObjects3= [];
gdjs.DeskPromptCode.GDhelpDialogueObjects1= [];
gdjs.DeskPromptCode.GDhelpDialogueObjects2= [];
gdjs.DeskPromptCode.GDhelpDialogueObjects3= [];
gdjs.DeskPromptCode.GDexitButtonObjects1= [];
gdjs.DeskPromptCode.GDexitButtonObjects2= [];
gdjs.DeskPromptCode.GDexitButtonObjects3= [];
gdjs.DeskPromptCode.GDhelpButtonObjects1= [];
gdjs.DeskPromptCode.GDhelpButtonObjects2= [];
gdjs.DeskPromptCode.GDhelpButtonObjects3= [];
gdjs.DeskPromptCode.GDexitDialogueObjects1= [];
gdjs.DeskPromptCode.GDexitDialogueObjects2= [];
gdjs.DeskPromptCode.GDexitDialogueObjects3= [];
gdjs.DeskPromptCode.GDYESObjects1= [];
gdjs.DeskPromptCode.GDYESObjects2= [];
gdjs.DeskPromptCode.GDYESObjects3= [];
gdjs.DeskPromptCode.GDNOObjects1= [];
gdjs.DeskPromptCode.GDNOObjects2= [];
gdjs.DeskPromptCode.GDNOObjects3= [];
gdjs.DeskPromptCode.GDCONFIRMObjects1= [];
gdjs.DeskPromptCode.GDCONFIRMObjects2= [];
gdjs.DeskPromptCode.GDCONFIRMObjects3= [];
gdjs.DeskPromptCode.GDDialogueObjects1= [];
gdjs.DeskPromptCode.GDDialogueObjects2= [];
gdjs.DeskPromptCode.GDDialogueObjects3= [];
gdjs.DeskPromptCode.GDNextObjects1= [];
gdjs.DeskPromptCode.GDNextObjects2= [];
gdjs.DeskPromptCode.GDNextObjects3= [];
gdjs.DeskPromptCode.GDsuccessDialogueObjects1= [];
gdjs.DeskPromptCode.GDsuccessDialogueObjects2= [];
gdjs.DeskPromptCode.GDsuccessDialogueObjects3= [];
gdjs.DeskPromptCode.GDTimerSecondsObjects1= [];
gdjs.DeskPromptCode.GDTimerSecondsObjects2= [];
gdjs.DeskPromptCode.GDTimerSecondsObjects3= [];
gdjs.DeskPromptCode.GDTimerMinutesObjects1= [];
gdjs.DeskPromptCode.GDTimerMinutesObjects2= [];
gdjs.DeskPromptCode.GDTimerMinutesObjects3= [];

gdjs.DeskPromptCode.conditionTrue_0 = {val:false};
gdjs.DeskPromptCode.condition0IsTrue_0 = {val:false};
gdjs.DeskPromptCode.condition1IsTrue_0 = {val:false};
gdjs.DeskPromptCode.condition2IsTrue_0 = {val:false};
gdjs.DeskPromptCode.condition3IsTrue_0 = {val:false};
gdjs.DeskPromptCode.condition4IsTrue_0 = {val:false};


gdjs.DeskPromptCode.mapOfGDgdjs_46DeskPromptCode_46GDDialogueBoxObjects1Objects = Hashtable.newFrom({"DialogueBox": gdjs.DeskPromptCode.GDDialogueBoxObjects1});gdjs.DeskPromptCode.mapOfGDgdjs_46DeskPromptCode_46GDNextObjects1Objects = Hashtable.newFrom({"Next": gdjs.DeskPromptCode.GDNextObjects1});gdjs.DeskPromptCode.mapOfGDgdjs_46DeskPromptCode_46GDNextObjects1Objects = Hashtable.newFrom({"Next": gdjs.DeskPromptCode.GDNextObjects1});gdjs.DeskPromptCode.eventsList0 = function(runtimeScene) {

{


gdjs.DeskPromptCode.condition0IsTrue_0.val = false;
{
gdjs.DeskPromptCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if (gdjs.DeskPromptCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("CodePrompt"), gdjs.DeskPromptCode.GDCodePromptObjects1);
gdjs.copyArray(runtimeScene.getObjects("Dialogue"), gdjs.DeskPromptCode.GDDialogueObjects1);
gdjs.copyArray(runtimeScene.getObjects("DialogueBox"), gdjs.DeskPromptCode.GDDialogueBoxObjects1);
gdjs.copyArray(runtimeScene.getObjects("Instructions"), gdjs.DeskPromptCode.GDInstructionsObjects1);
/* Reuse gdjs.DeskPromptCode.GDNextObjects1 */
gdjs.copyArray(runtimeScene.getObjects("body"), gdjs.DeskPromptCode.GDbodyObjects1);
gdjs.copyArray(runtimeScene.getObjects("box1"), gdjs.DeskPromptCode.GDbox1Objects1);
gdjs.copyArray(runtimeScene.getObjects("box2"), gdjs.DeskPromptCode.GDbox2Objects1);
gdjs.copyArray(runtimeScene.getObjects("box3"), gdjs.DeskPromptCode.GDbox3Objects1);
gdjs.copyArray(runtimeScene.getObjects("box4"), gdjs.DeskPromptCode.GDbox4Objects1);
gdjs.copyArray(runtimeScene.getObjects("exitButton"), gdjs.DeskPromptCode.GDexitButtonObjects1);
gdjs.copyArray(runtimeScene.getObjects("for"), gdjs.DeskPromptCode.GDforObjects1);
gdjs.copyArray(runtimeScene.getObjects("helpButton"), gdjs.DeskPromptCode.GDhelpButtonObjects1);
gdjs.copyArray(runtimeScene.getObjects("if"), gdjs.DeskPromptCode.GDifObjects1);
gdjs.copyArray(runtimeScene.getObjects("pieceBreak"), gdjs.DeskPromptCode.GDpieceBreakObjects1);
gdjs.copyArray(runtimeScene.getObjects("pieceClue"), gdjs.DeskPromptCode.GDpieceClueObjects1);
gdjs.copyArray(runtimeScene.getObjects("pieceEnd"), gdjs.DeskPromptCode.GDpieceEndObjects1);
gdjs.copyArray(runtimeScene.getObjects("pieceStart"), gdjs.DeskPromptCode.GDpieceStartObjects1);
{for(var i = 0, len = gdjs.DeskPromptCode.GDDialogueBoxObjects1.length ;i < len;++i) {
    gdjs.DeskPromptCode.GDDialogueBoxObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.DeskPromptCode.GDNextObjects1.length ;i < len;++i) {
    gdjs.DeskPromptCode.GDNextObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.DeskPromptCode.GDDialogueObjects1.length ;i < len;++i) {
    gdjs.DeskPromptCode.GDDialogueObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.DeskPromptCode.GDCodePromptObjects1.length ;i < len;++i) {
    gdjs.DeskPromptCode.GDCodePromptObjects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.DeskPromptCode.GDInstructionsObjects1.length ;i < len;++i) {
    gdjs.DeskPromptCode.GDInstructionsObjects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.DeskPromptCode.GDforObjects1.length ;i < len;++i) {
    gdjs.DeskPromptCode.GDforObjects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.DeskPromptCode.GDifObjects1.length ;i < len;++i) {
    gdjs.DeskPromptCode.GDifObjects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.DeskPromptCode.GDbodyObjects1.length ;i < len;++i) {
    gdjs.DeskPromptCode.GDbodyObjects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.DeskPromptCode.GDpieceStartObjects1.length ;i < len;++i) {
    gdjs.DeskPromptCode.GDpieceStartObjects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.DeskPromptCode.GDpieceEndObjects1.length ;i < len;++i) {
    gdjs.DeskPromptCode.GDpieceEndObjects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.DeskPromptCode.GDpieceClueObjects1.length ;i < len;++i) {
    gdjs.DeskPromptCode.GDpieceClueObjects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.DeskPromptCode.GDpieceBreakObjects1.length ;i < len;++i) {
    gdjs.DeskPromptCode.GDpieceBreakObjects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.DeskPromptCode.GDbox1Objects1.length ;i < len;++i) {
    gdjs.DeskPromptCode.GDbox1Objects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.DeskPromptCode.GDbox2Objects1.length ;i < len;++i) {
    gdjs.DeskPromptCode.GDbox2Objects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.DeskPromptCode.GDbox3Objects1.length ;i < len;++i) {
    gdjs.DeskPromptCode.GDbox3Objects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.DeskPromptCode.GDbox4Objects1.length ;i < len;++i) {
    gdjs.DeskPromptCode.GDbox4Objects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.DeskPromptCode.GDhelpButtonObjects1.length ;i < len;++i) {
    gdjs.DeskPromptCode.GDhelpButtonObjects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.DeskPromptCode.GDexitButtonObjects1.length ;i < len;++i) {
    gdjs.DeskPromptCode.GDexitButtonObjects1[i].hide(false);
}
}}

}


};gdjs.DeskPromptCode.mapOfGDgdjs_46DeskPromptCode_46GDNextObjects1Objects = Hashtable.newFrom({"Next": gdjs.DeskPromptCode.GDNextObjects1});gdjs.DeskPromptCode.mapOfGDgdjs_46DeskPromptCode_46GDpieceStartObjects1Objects = Hashtable.newFrom({"pieceStart": gdjs.DeskPromptCode.GDpieceStartObjects1});gdjs.DeskPromptCode.mapOfGDgdjs_46DeskPromptCode_46GDbox1Objects1Objects = Hashtable.newFrom({"box1": gdjs.DeskPromptCode.GDbox1Objects1});gdjs.DeskPromptCode.mapOfGDgdjs_46DeskPromptCode_46GDpieceEndObjects1Objects = Hashtable.newFrom({"pieceEnd": gdjs.DeskPromptCode.GDpieceEndObjects1});gdjs.DeskPromptCode.mapOfGDgdjs_46DeskPromptCode_46GDbox2Objects1Objects = Hashtable.newFrom({"box2": gdjs.DeskPromptCode.GDbox2Objects1});gdjs.DeskPromptCode.mapOfGDgdjs_46DeskPromptCode_46GDpieceClueObjects1Objects = Hashtable.newFrom({"pieceClue": gdjs.DeskPromptCode.GDpieceClueObjects1});gdjs.DeskPromptCode.mapOfGDgdjs_46DeskPromptCode_46GDbox3Objects1Objects = Hashtable.newFrom({"box3": gdjs.DeskPromptCode.GDbox3Objects1});gdjs.DeskPromptCode.mapOfGDgdjs_46DeskPromptCode_46GDpieceBreakObjects1Objects = Hashtable.newFrom({"pieceBreak": gdjs.DeskPromptCode.GDpieceBreakObjects1});gdjs.DeskPromptCode.mapOfGDgdjs_46DeskPromptCode_46GDbox4Objects1Objects = Hashtable.newFrom({"box4": gdjs.DeskPromptCode.GDbox4Objects1});gdjs.DeskPromptCode.mapOfGDgdjs_46DeskPromptCode_46GDDialogueBoxObjects1Objects = Hashtable.newFrom({"DialogueBox": gdjs.DeskPromptCode.GDDialogueBoxObjects1});gdjs.DeskPromptCode.mapOfGDgdjs_46DeskPromptCode_46GDCONFIRMObjects1Objects = Hashtable.newFrom({"CONFIRM": gdjs.DeskPromptCode.GDCONFIRMObjects1});gdjs.DeskPromptCode.eventsList1 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("box1"), gdjs.DeskPromptCode.GDbox1Objects1);
gdjs.copyArray(runtimeScene.getObjects("box2"), gdjs.DeskPromptCode.GDbox2Objects1);
gdjs.copyArray(runtimeScene.getObjects("box3"), gdjs.DeskPromptCode.GDbox3Objects1);
gdjs.copyArray(runtimeScene.getObjects("box4"), gdjs.DeskPromptCode.GDbox4Objects1);
gdjs.copyArray(runtimeScene.getObjects("pieceBreak"), gdjs.DeskPromptCode.GDpieceBreakObjects1);
gdjs.copyArray(runtimeScene.getObjects("pieceClue"), gdjs.DeskPromptCode.GDpieceClueObjects1);
gdjs.copyArray(runtimeScene.getObjects("pieceEnd"), gdjs.DeskPromptCode.GDpieceEndObjects1);
gdjs.copyArray(runtimeScene.getObjects("pieceStart"), gdjs.DeskPromptCode.GDpieceStartObjects1);

gdjs.DeskPromptCode.condition0IsTrue_0.val = false;
gdjs.DeskPromptCode.condition1IsTrue_0.val = false;
gdjs.DeskPromptCode.condition2IsTrue_0.val = false;
gdjs.DeskPromptCode.condition3IsTrue_0.val = false;
{
gdjs.DeskPromptCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.DeskPromptCode.mapOfGDgdjs_46DeskPromptCode_46GDpieceStartObjects1Objects, gdjs.DeskPromptCode.mapOfGDgdjs_46DeskPromptCode_46GDbox1Objects1Objects, false, runtimeScene, true);
}if ( gdjs.DeskPromptCode.condition0IsTrue_0.val ) {
{
gdjs.DeskPromptCode.condition1IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.DeskPromptCode.mapOfGDgdjs_46DeskPromptCode_46GDpieceEndObjects1Objects, gdjs.DeskPromptCode.mapOfGDgdjs_46DeskPromptCode_46GDbox2Objects1Objects, false, runtimeScene, true);
}if ( gdjs.DeskPromptCode.condition1IsTrue_0.val ) {
{
gdjs.DeskPromptCode.condition2IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.DeskPromptCode.mapOfGDgdjs_46DeskPromptCode_46GDpieceClueObjects1Objects, gdjs.DeskPromptCode.mapOfGDgdjs_46DeskPromptCode_46GDbox3Objects1Objects, false, runtimeScene, true);
}if ( gdjs.DeskPromptCode.condition2IsTrue_0.val ) {
{
gdjs.DeskPromptCode.condition3IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.DeskPromptCode.mapOfGDgdjs_46DeskPromptCode_46GDpieceBreakObjects1Objects, gdjs.DeskPromptCode.mapOfGDgdjs_46DeskPromptCode_46GDbox4Objects1Objects, false, runtimeScene, true);
}}
}
}
if (gdjs.DeskPromptCode.condition3IsTrue_0.val) {
/* Reuse gdjs.DeskPromptCode.GDsuccessDialogueObjects1 */
gdjs.DeskPromptCode.GDCONFIRMObjects1.length = 0;

gdjs.DeskPromptCode.GDDialogueBoxObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.DeskPromptCode.mapOfGDgdjs_46DeskPromptCode_46GDDialogueBoxObjects1Objects, 60, 350, "");
}{for(var i = 0, len = gdjs.DeskPromptCode.GDDialogueBoxObjects1.length ;i < len;++i) {
    gdjs.DeskPromptCode.GDDialogueBoxObjects1[i].setScale(gdjs.DeskPromptCode.GDDialogueBoxObjects1[i].getScale() / (2));
}
}{for(var i = 0, len = gdjs.DeskPromptCode.GDDialogueBoxObjects1.length ;i < len;++i) {
    gdjs.DeskPromptCode.GDDialogueBoxObjects1[i].setOpacity(215);
}
}{for(var i = 0, len = gdjs.DeskPromptCode.GDDialogueBoxObjects1.length ;i < len;++i) {
    gdjs.DeskPromptCode.GDDialogueBoxObjects1[i].setZOrder(900);
}
}{for(var i = 0, len = gdjs.DeskPromptCode.GDsuccessDialogueObjects1.length ;i < len;++i) {
    gdjs.DeskPromptCode.GDsuccessDialogueObjects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.DeskPromptCode.GDsuccessDialogueObjects1.length ;i < len;++i) {
    gdjs.DeskPromptCode.GDsuccessDialogueObjects1[i].setZOrder(910);
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.DeskPromptCode.mapOfGDgdjs_46DeskPromptCode_46GDCONFIRMObjects1Objects, 400, 630, "");
}{for(var i = 0, len = gdjs.DeskPromptCode.GDCONFIRMObjects1.length ;i < len;++i) {
    gdjs.DeskPromptCode.GDCONFIRMObjects1[i].setZOrder(920);
}
}}

}


};gdjs.DeskPromptCode.mapOfGDgdjs_46DeskPromptCode_46GDCONFIRMObjects1Objects = Hashtable.newFrom({"CONFIRM": gdjs.DeskPromptCode.GDCONFIRMObjects1});gdjs.DeskPromptCode.eventsList2 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("helpDialogue"), gdjs.DeskPromptCode.GDhelpDialogueObjects1);

gdjs.DeskPromptCode.condition0IsTrue_0.val = false;
gdjs.DeskPromptCode.condition1IsTrue_0.val = false;
{
gdjs.DeskPromptCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if ( gdjs.DeskPromptCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.DeskPromptCode.GDhelpDialogueObjects1.length;i<l;++i) {
    if ( !(gdjs.DeskPromptCode.GDhelpDialogueObjects1[i].isVisible()) ) {
        gdjs.DeskPromptCode.condition1IsTrue_0.val = true;
        gdjs.DeskPromptCode.GDhelpDialogueObjects1[k] = gdjs.DeskPromptCode.GDhelpDialogueObjects1[i];
        ++k;
    }
}
gdjs.DeskPromptCode.GDhelpDialogueObjects1.length = k;}}
if (gdjs.DeskPromptCode.condition1IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "DeskSuccess", false);
}}

}


};gdjs.DeskPromptCode.mapOfGDgdjs_46DeskPromptCode_46GDhelpButtonObjects1Objects = Hashtable.newFrom({"helpButton": gdjs.DeskPromptCode.GDhelpButtonObjects1});gdjs.DeskPromptCode.eventsList3 = function(runtimeScene) {

{


gdjs.DeskPromptCode.condition0IsTrue_0.val = false;
{
gdjs.DeskPromptCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if (gdjs.DeskPromptCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("CONFIRM"), gdjs.DeskPromptCode.GDCONFIRMObjects1);
gdjs.copyArray(runtimeScene.getObjects("DialogueBox"), gdjs.DeskPromptCode.GDDialogueBoxObjects1);
/* Reuse gdjs.DeskPromptCode.GDhelpDialogueObjects1 */
{for(var i = 0, len = gdjs.DeskPromptCode.GDDialogueBoxObjects1.length ;i < len;++i) {
    gdjs.DeskPromptCode.GDDialogueBoxObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.DeskPromptCode.GDhelpDialogueObjects1.length ;i < len;++i) {
    gdjs.DeskPromptCode.GDhelpDialogueObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.DeskPromptCode.GDCONFIRMObjects1.length ;i < len;++i) {
    gdjs.DeskPromptCode.GDCONFIRMObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.DeskPromptCode.mapOfGDgdjs_46DeskPromptCode_46GDhelpButtonObjects1Objects = Hashtable.newFrom({"helpButton": gdjs.DeskPromptCode.GDhelpButtonObjects1});gdjs.DeskPromptCode.mapOfGDgdjs_46DeskPromptCode_46GDDialogueBoxObjects1Objects = Hashtable.newFrom({"DialogueBox": gdjs.DeskPromptCode.GDDialogueBoxObjects1});gdjs.DeskPromptCode.mapOfGDgdjs_46DeskPromptCode_46GDCONFIRMObjects1Objects = Hashtable.newFrom({"CONFIRM": gdjs.DeskPromptCode.GDCONFIRMObjects1});gdjs.DeskPromptCode.eventsList4 = function(runtimeScene) {

{


gdjs.DeskPromptCode.condition0IsTrue_0.val = false;
{
gdjs.DeskPromptCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if (gdjs.DeskPromptCode.condition0IsTrue_0.val) {
/* Reuse gdjs.DeskPromptCode.GDhelpDialogueObjects1 */
/* Reuse gdjs.DeskPromptCode.GDsuccessDialogueObjects1 */
gdjs.DeskPromptCode.GDCONFIRMObjects1.length = 0;

gdjs.DeskPromptCode.GDDialogueBoxObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.DeskPromptCode.mapOfGDgdjs_46DeskPromptCode_46GDDialogueBoxObjects1Objects, 60, 350, "");
}{for(var i = 0, len = gdjs.DeskPromptCode.GDDialogueBoxObjects1.length ;i < len;++i) {
    gdjs.DeskPromptCode.GDDialogueBoxObjects1[i].setScale(gdjs.DeskPromptCode.GDDialogueBoxObjects1[i].getScale() / (2));
}
}{for(var i = 0, len = gdjs.DeskPromptCode.GDDialogueBoxObjects1.length ;i < len;++i) {
    gdjs.DeskPromptCode.GDDialogueBoxObjects1[i].setOpacity(215);
}
}{for(var i = 0, len = gdjs.DeskPromptCode.GDhelpDialogueObjects1.length ;i < len;++i) {
    gdjs.DeskPromptCode.GDhelpDialogueObjects1[i].hide(false);
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.DeskPromptCode.mapOfGDgdjs_46DeskPromptCode_46GDCONFIRMObjects1Objects, 425, 640, "");
}{for(var i = 0, len = gdjs.DeskPromptCode.GDDialogueBoxObjects1.length ;i < len;++i) {
    gdjs.DeskPromptCode.GDDialogueBoxObjects1[i].setZOrder(900);
}
}{for(var i = 0, len = gdjs.DeskPromptCode.GDhelpDialogueObjects1.length ;i < len;++i) {
    gdjs.DeskPromptCode.GDhelpDialogueObjects1[i].setZOrder(910);
}
}{for(var i = 0, len = gdjs.DeskPromptCode.GDCONFIRMObjects1.length ;i < len;++i) {
    gdjs.DeskPromptCode.GDCONFIRMObjects1[i].setZOrder(920);
}
}{for(var i = 0, len = gdjs.DeskPromptCode.GDsuccessDialogueObjects1.length ;i < len;++i) {
    gdjs.DeskPromptCode.GDsuccessDialogueObjects1[i].hide();
}
}}

}


};gdjs.DeskPromptCode.mapOfGDgdjs_46DeskPromptCode_46GDCONFIRMObjects1Objects = Hashtable.newFrom({"CONFIRM": gdjs.DeskPromptCode.GDCONFIRMObjects1});gdjs.DeskPromptCode.eventsList5 = function(runtimeScene) {

{


gdjs.DeskPromptCode.condition0IsTrue_0.val = false;
{
gdjs.DeskPromptCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if (gdjs.DeskPromptCode.condition0IsTrue_0.val) {
/* Reuse gdjs.DeskPromptCode.GDCONFIRMObjects1 */
gdjs.copyArray(runtimeScene.getObjects("DialogueBox"), gdjs.DeskPromptCode.GDDialogueBoxObjects1);
gdjs.copyArray(runtimeScene.getObjects("helpDialogue"), gdjs.DeskPromptCode.GDhelpDialogueObjects1);
{for(var i = 0, len = gdjs.DeskPromptCode.GDDialogueBoxObjects1.length ;i < len;++i) {
    gdjs.DeskPromptCode.GDDialogueBoxObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.DeskPromptCode.GDhelpDialogueObjects1.length ;i < len;++i) {
    gdjs.DeskPromptCode.GDhelpDialogueObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.DeskPromptCode.GDCONFIRMObjects1.length ;i < len;++i) {
    gdjs.DeskPromptCode.GDCONFIRMObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.DeskPromptCode.mapOfGDgdjs_46DeskPromptCode_46GDCONFIRMObjects1Objects = Hashtable.newFrom({"CONFIRM": gdjs.DeskPromptCode.GDCONFIRMObjects1});gdjs.DeskPromptCode.mapOfGDgdjs_46DeskPromptCode_46GDexitButtonObjects1Objects = Hashtable.newFrom({"exitButton": gdjs.DeskPromptCode.GDexitButtonObjects1});gdjs.DeskPromptCode.eventsList6 = function(runtimeScene) {

{


gdjs.DeskPromptCode.condition0IsTrue_0.val = false;
{
gdjs.DeskPromptCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if (gdjs.DeskPromptCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("CONFIRM"), gdjs.DeskPromptCode.GDCONFIRMObjects1);
gdjs.copyArray(runtimeScene.getObjects("DialogueBox"), gdjs.DeskPromptCode.GDDialogueBoxObjects1);
/* Reuse gdjs.DeskPromptCode.GDexitDialogueObjects1 */
{for(var i = 0, len = gdjs.DeskPromptCode.GDDialogueBoxObjects1.length ;i < len;++i) {
    gdjs.DeskPromptCode.GDDialogueBoxObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.DeskPromptCode.GDexitDialogueObjects1.length ;i < len;++i) {
    gdjs.DeskPromptCode.GDexitDialogueObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.DeskPromptCode.GDCONFIRMObjects1.length ;i < len;++i) {
    gdjs.DeskPromptCode.GDCONFIRMObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.DeskPromptCode.mapOfGDgdjs_46DeskPromptCode_46GDexitButtonObjects1Objects = Hashtable.newFrom({"exitButton": gdjs.DeskPromptCode.GDexitButtonObjects1});gdjs.DeskPromptCode.mapOfGDgdjs_46DeskPromptCode_46GDDialogueBoxObjects1Objects = Hashtable.newFrom({"DialogueBox": gdjs.DeskPromptCode.GDDialogueBoxObjects1});gdjs.DeskPromptCode.mapOfGDgdjs_46DeskPromptCode_46GDYESObjects1Objects = Hashtable.newFrom({"YES": gdjs.DeskPromptCode.GDYESObjects1});gdjs.DeskPromptCode.mapOfGDgdjs_46DeskPromptCode_46GDNOObjects1Objects = Hashtable.newFrom({"NO": gdjs.DeskPromptCode.GDNOObjects1});gdjs.DeskPromptCode.eventsList7 = function(runtimeScene) {

{


gdjs.DeskPromptCode.condition0IsTrue_0.val = false;
{
gdjs.DeskPromptCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if (gdjs.DeskPromptCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("CONFIRM"), gdjs.DeskPromptCode.GDCONFIRMObjects1);
gdjs.copyArray(runtimeScene.getObjects("DialogueBox"), gdjs.DeskPromptCode.GDDialogueBoxObjects1);
gdjs.copyArray(runtimeScene.getObjects("NO"), gdjs.DeskPromptCode.GDNOObjects1);
gdjs.copyArray(runtimeScene.getObjects("YES"), gdjs.DeskPromptCode.GDYESObjects1);
/* Reuse gdjs.DeskPromptCode.GDexitDialogueObjects1 */
gdjs.copyArray(runtimeScene.getObjects("helpDialogue"), gdjs.DeskPromptCode.GDhelpDialogueObjects1);
/* Reuse gdjs.DeskPromptCode.GDsuccessDialogueObjects1 */
{for(var i = 0, len = gdjs.DeskPromptCode.GDDialogueBoxObjects1.length ;i < len;++i) {
    gdjs.DeskPromptCode.GDDialogueBoxObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.DeskPromptCode.GDYESObjects1.length ;i < len;++i) {
    gdjs.DeskPromptCode.GDYESObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.DeskPromptCode.GDNOObjects1.length ;i < len;++i) {
    gdjs.DeskPromptCode.GDNOObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.DeskPromptCode.GDCONFIRMObjects1.length ;i < len;++i) {
    gdjs.DeskPromptCode.GDCONFIRMObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.DeskPromptCode.GDhelpDialogueObjects1.length ;i < len;++i) {
    gdjs.DeskPromptCode.GDhelpDialogueObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.DeskPromptCode.GDsuccessDialogueObjects1.length ;i < len;++i) {
    gdjs.DeskPromptCode.GDsuccessDialogueObjects1[i].hide();
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.DeskPromptCode.mapOfGDgdjs_46DeskPromptCode_46GDDialogueBoxObjects1Objects, 60, 350, "");
}{for(var i = 0, len = gdjs.DeskPromptCode.GDDialogueBoxObjects1.length ;i < len;++i) {
    gdjs.DeskPromptCode.GDDialogueBoxObjects1[i].setScale(gdjs.DeskPromptCode.GDDialogueBoxObjects1[i].getScale() / (2));
}
}{for(var i = 0, len = gdjs.DeskPromptCode.GDDialogueBoxObjects1.length ;i < len;++i) {
    gdjs.DeskPromptCode.GDDialogueBoxObjects1[i].setOpacity(215);
}
}{for(var i = 0, len = gdjs.DeskPromptCode.GDexitDialogueObjects1.length ;i < len;++i) {
    gdjs.DeskPromptCode.GDexitDialogueObjects1[i].hide(false);
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.DeskPromptCode.mapOfGDgdjs_46DeskPromptCode_46GDYESObjects1Objects, 355, 600, "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.DeskPromptCode.mapOfGDgdjs_46DeskPromptCode_46GDNOObjects1Objects, 580, 600, "");
}{for(var i = 0, len = gdjs.DeskPromptCode.GDDialogueBoxObjects1.length ;i < len;++i) {
    gdjs.DeskPromptCode.GDDialogueBoxObjects1[i].setZOrder(900);
}
}{for(var i = 0, len = gdjs.DeskPromptCode.GDexitDialogueObjects1.length ;i < len;++i) {
    gdjs.DeskPromptCode.GDexitDialogueObjects1[i].setZOrder(910);
}
}{for(var i = 0, len = gdjs.DeskPromptCode.GDYESObjects1.length ;i < len;++i) {
    gdjs.DeskPromptCode.GDYESObjects1[i].setZOrder(920);
}
}{for(var i = 0, len = gdjs.DeskPromptCode.GDNOObjects1.length ;i < len;++i) {
    gdjs.DeskPromptCode.GDNOObjects1[i].setZOrder(920);
}
}}

}


};gdjs.DeskPromptCode.mapOfGDgdjs_46DeskPromptCode_46GDYESObjects1Objects = Hashtable.newFrom({"YES": gdjs.DeskPromptCode.GDYESObjects1});gdjs.DeskPromptCode.eventsList8 = function(runtimeScene) {

{


gdjs.DeskPromptCode.condition0IsTrue_0.val = false;
{
gdjs.DeskPromptCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if (gdjs.DeskPromptCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.popScene(runtimeScene);
}}

}


};gdjs.DeskPromptCode.mapOfGDgdjs_46DeskPromptCode_46GDNOObjects1Objects = Hashtable.newFrom({"NO": gdjs.DeskPromptCode.GDNOObjects1});gdjs.DeskPromptCode.eventsList9 = function(runtimeScene) {

{


gdjs.DeskPromptCode.condition0IsTrue_0.val = false;
{
gdjs.DeskPromptCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if (gdjs.DeskPromptCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("DialogueBox"), gdjs.DeskPromptCode.GDDialogueBoxObjects1);
/* Reuse gdjs.DeskPromptCode.GDNOObjects1 */
gdjs.copyArray(runtimeScene.getObjects("YES"), gdjs.DeskPromptCode.GDYESObjects1);
gdjs.copyArray(runtimeScene.getObjects("exitDialogue"), gdjs.DeskPromptCode.GDexitDialogueObjects1);
{for(var i = 0, len = gdjs.DeskPromptCode.GDDialogueBoxObjects1.length ;i < len;++i) {
    gdjs.DeskPromptCode.GDDialogueBoxObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.DeskPromptCode.GDexitDialogueObjects1.length ;i < len;++i) {
    gdjs.DeskPromptCode.GDexitDialogueObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.DeskPromptCode.GDYESObjects1.length ;i < len;++i) {
    gdjs.DeskPromptCode.GDYESObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.DeskPromptCode.GDNOObjects1.length ;i < len;++i) {
    gdjs.DeskPromptCode.GDNOObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.DeskPromptCode.mapOfGDgdjs_46DeskPromptCode_46GDYESObjects1Objects = Hashtable.newFrom({"YES": gdjs.DeskPromptCode.GDYESObjects1});gdjs.DeskPromptCode.mapOfGDgdjs_46DeskPromptCode_46GDNOObjects1Objects = Hashtable.newFrom({"NO": gdjs.DeskPromptCode.GDNOObjects1});gdjs.DeskPromptCode.eventsList10 = function(runtimeScene) {

{


gdjs.DeskPromptCode.condition0IsTrue_0.val = false;
gdjs.DeskPromptCode.condition1IsTrue_0.val = false;
{
gdjs.DeskPromptCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)) < 1800;
}if ( gdjs.DeskPromptCode.condition0IsTrue_0.val ) {
{
gdjs.DeskPromptCode.condition1IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)) > 540;
}}
if (gdjs.DeskPromptCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("TimerMinutes"), gdjs.DeskPromptCode.GDTimerMinutesObjects2);
{for(var i = 0, len = gdjs.DeskPromptCode.GDTimerMinutesObjects2.length ;i < len;++i) {
    gdjs.DeskPromptCode.GDTimerMinutesObjects2[i].setString(gdjs.evtTools.common.toString(Math.floor(gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)) / 60)) + ":");
}
}}

}


{


gdjs.DeskPromptCode.condition0IsTrue_0.val = false;
{
gdjs.DeskPromptCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)) < 600;
}if (gdjs.DeskPromptCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("TimerMinutes"), gdjs.DeskPromptCode.GDTimerMinutesObjects2);
{for(var i = 0, len = gdjs.DeskPromptCode.GDTimerMinutesObjects2.length ;i < len;++i) {
    gdjs.DeskPromptCode.GDTimerMinutesObjects2[i].setString("0" + gdjs.evtTools.common.toString(Math.floor(gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)) / 60)) + ":");
}
}}

}


{


gdjs.DeskPromptCode.condition0IsTrue_0.val = false;
{
gdjs.DeskPromptCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)) < 1800;
}if (gdjs.DeskPromptCode.condition0IsTrue_0.val) {
{runtimeScene.getGame().getVariables().getFromIndex(4).sub(gdjs.evtTools.runtimeScene.getElapsedTimeInSeconds(runtimeScene));
}}

}


{


gdjs.DeskPromptCode.condition0IsTrue_0.val = false;
gdjs.DeskPromptCode.condition1IsTrue_0.val = false;
{
gdjs.DeskPromptCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4)) < 60;
}if ( gdjs.DeskPromptCode.condition0IsTrue_0.val ) {
{
gdjs.DeskPromptCode.condition1IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4)) > 9;
}}
if (gdjs.DeskPromptCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("TimerSeconds"), gdjs.DeskPromptCode.GDTimerSecondsObjects2);
{for(var i = 0, len = gdjs.DeskPromptCode.GDTimerSecondsObjects2.length ;i < len;++i) {
    gdjs.DeskPromptCode.GDTimerSecondsObjects2[i].setString(gdjs.evtTools.common.toString(Math.floor(gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4)))));
}
}}

}


{


gdjs.DeskPromptCode.condition0IsTrue_0.val = false;
{
gdjs.DeskPromptCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4)) < 10;
}if (gdjs.DeskPromptCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("TimerSeconds"), gdjs.DeskPromptCode.GDTimerSecondsObjects2);
{for(var i = 0, len = gdjs.DeskPromptCode.GDTimerSecondsObjects2.length ;i < len;++i) {
    gdjs.DeskPromptCode.GDTimerSecondsObjects2[i].setString("0" + gdjs.evtTools.common.toString(Math.floor(gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(4)))));
}
}}

}


{


gdjs.DeskPromptCode.condition0IsTrue_0.val = false;
{
gdjs.DeskPromptCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(3)) == 0;
}if (gdjs.DeskPromptCode.condition0IsTrue_0.val) {
{runtimeScene.getGame().getVariables().getFromIndex(4).setNumber(59);
}}

}


{



}


};gdjs.DeskPromptCode.eventsList11 = function(runtimeScene) {

{


{
{runtimeScene.getGame().getVariables().getFromIndex(3).sub(gdjs.evtTools.runtimeScene.getElapsedTimeInSeconds(runtimeScene));
}
{ //Subevents
gdjs.DeskPromptCode.eventsList10(runtimeScene);} //End of subevents
}

}


};gdjs.DeskPromptCode.eventsList12 = function(runtimeScene) {

{



}


{


gdjs.DeskPromptCode.condition0IsTrue_0.val = false;
{
gdjs.DeskPromptCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.DeskPromptCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("CodePrompt"), gdjs.DeskPromptCode.GDCodePromptObjects1);
gdjs.copyArray(runtimeScene.getObjects("Instructions"), gdjs.DeskPromptCode.GDInstructionsObjects1);
gdjs.copyArray(runtimeScene.getObjects("body"), gdjs.DeskPromptCode.GDbodyObjects1);
gdjs.copyArray(runtimeScene.getObjects("box1"), gdjs.DeskPromptCode.GDbox1Objects1);
gdjs.copyArray(runtimeScene.getObjects("box2"), gdjs.DeskPromptCode.GDbox2Objects1);
gdjs.copyArray(runtimeScene.getObjects("box3"), gdjs.DeskPromptCode.GDbox3Objects1);
gdjs.copyArray(runtimeScene.getObjects("box4"), gdjs.DeskPromptCode.GDbox4Objects1);
gdjs.copyArray(runtimeScene.getObjects("exitButton"), gdjs.DeskPromptCode.GDexitButtonObjects1);
gdjs.copyArray(runtimeScene.getObjects("exitDialogue"), gdjs.DeskPromptCode.GDexitDialogueObjects1);
gdjs.copyArray(runtimeScene.getObjects("for"), gdjs.DeskPromptCode.GDforObjects1);
gdjs.copyArray(runtimeScene.getObjects("helpButton"), gdjs.DeskPromptCode.GDhelpButtonObjects1);
gdjs.copyArray(runtimeScene.getObjects("helpDialogue"), gdjs.DeskPromptCode.GDhelpDialogueObjects1);
gdjs.copyArray(runtimeScene.getObjects("if"), gdjs.DeskPromptCode.GDifObjects1);
gdjs.copyArray(runtimeScene.getObjects("pieceBreak"), gdjs.DeskPromptCode.GDpieceBreakObjects1);
gdjs.copyArray(runtimeScene.getObjects("pieceClue"), gdjs.DeskPromptCode.GDpieceClueObjects1);
gdjs.copyArray(runtimeScene.getObjects("pieceEnd"), gdjs.DeskPromptCode.GDpieceEndObjects1);
gdjs.copyArray(runtimeScene.getObjects("pieceStart"), gdjs.DeskPromptCode.GDpieceStartObjects1);
gdjs.copyArray(runtimeScene.getObjects("successDialogue"), gdjs.DeskPromptCode.GDsuccessDialogueObjects1);
gdjs.DeskPromptCode.GDDialogueBoxObjects1.length = 0;

gdjs.DeskPromptCode.GDNextObjects1.length = 0;

{for(var i = 0, len = gdjs.DeskPromptCode.GDhelpDialogueObjects1.length ;i < len;++i) {
    gdjs.DeskPromptCode.GDhelpDialogueObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.DeskPromptCode.GDexitDialogueObjects1.length ;i < len;++i) {
    gdjs.DeskPromptCode.GDexitDialogueObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.DeskPromptCode.GDCodePromptObjects1.length ;i < len;++i) {
    gdjs.DeskPromptCode.GDCodePromptObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.DeskPromptCode.GDInstructionsObjects1.length ;i < len;++i) {
    gdjs.DeskPromptCode.GDInstructionsObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.DeskPromptCode.GDforObjects1.length ;i < len;++i) {
    gdjs.DeskPromptCode.GDforObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.DeskPromptCode.GDifObjects1.length ;i < len;++i) {
    gdjs.DeskPromptCode.GDifObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.DeskPromptCode.GDbodyObjects1.length ;i < len;++i) {
    gdjs.DeskPromptCode.GDbodyObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.DeskPromptCode.GDpieceStartObjects1.length ;i < len;++i) {
    gdjs.DeskPromptCode.GDpieceStartObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.DeskPromptCode.GDpieceEndObjects1.length ;i < len;++i) {
    gdjs.DeskPromptCode.GDpieceEndObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.DeskPromptCode.GDpieceClueObjects1.length ;i < len;++i) {
    gdjs.DeskPromptCode.GDpieceClueObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.DeskPromptCode.GDpieceBreakObjects1.length ;i < len;++i) {
    gdjs.DeskPromptCode.GDpieceBreakObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.DeskPromptCode.GDbox1Objects1.length ;i < len;++i) {
    gdjs.DeskPromptCode.GDbox1Objects1[i].hide();
}
}{for(var i = 0, len = gdjs.DeskPromptCode.GDbox2Objects1.length ;i < len;++i) {
    gdjs.DeskPromptCode.GDbox2Objects1[i].hide();
}
}{for(var i = 0, len = gdjs.DeskPromptCode.GDbox3Objects1.length ;i < len;++i) {
    gdjs.DeskPromptCode.GDbox3Objects1[i].hide();
}
}{for(var i = 0, len = gdjs.DeskPromptCode.GDbox4Objects1.length ;i < len;++i) {
    gdjs.DeskPromptCode.GDbox4Objects1[i].hide();
}
}{for(var i = 0, len = gdjs.DeskPromptCode.GDhelpButtonObjects1.length ;i < len;++i) {
    gdjs.DeskPromptCode.GDhelpButtonObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.DeskPromptCode.GDexitButtonObjects1.length ;i < len;++i) {
    gdjs.DeskPromptCode.GDexitButtonObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.DeskPromptCode.GDsuccessDialogueObjects1.length ;i < len;++i) {
    gdjs.DeskPromptCode.GDsuccessDialogueObjects1[i].hide();
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.DeskPromptCode.mapOfGDgdjs_46DeskPromptCode_46GDDialogueBoxObjects1Objects, 60, 576, "");
}{for(var i = 0, len = gdjs.DeskPromptCode.GDDialogueBoxObjects1.length ;i < len;++i) {
    gdjs.DeskPromptCode.GDDialogueBoxObjects1[i].setScale(gdjs.DeskPromptCode.GDDialogueBoxObjects1[i].getScale() / (2));
}
}{for(var i = 0, len = gdjs.DeskPromptCode.GDDialogueBoxObjects1.length ;i < len;++i) {
    gdjs.DeskPromptCode.GDDialogueBoxObjects1[i].setOpacity(215);
}
}{for(var i = 0, len = gdjs.DeskPromptCode.GDDialogueBoxObjects1.length ;i < len;++i) {
    gdjs.DeskPromptCode.GDDialogueBoxObjects1[i].setZOrder(20);
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.DeskPromptCode.mapOfGDgdjs_46DeskPromptCode_46GDNextObjects1Objects, 760, 870, "");
}{for(var i = 0, len = gdjs.DeskPromptCode.GDNextObjects1.length ;i < len;++i) {
    gdjs.DeskPromptCode.GDNextObjects1[i].setZOrder(25);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Next"), gdjs.DeskPromptCode.GDNextObjects1);

gdjs.DeskPromptCode.condition0IsTrue_0.val = false;
{
gdjs.DeskPromptCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.DeskPromptCode.mapOfGDgdjs_46DeskPromptCode_46GDNextObjects1Objects, runtimeScene, true, false);
}if (gdjs.DeskPromptCode.condition0IsTrue_0.val) {
/* Reuse gdjs.DeskPromptCode.GDNextObjects1 */
{for(var i = 0, len = gdjs.DeskPromptCode.GDNextObjects1.length ;i < len;++i) {
    gdjs.DeskPromptCode.GDNextObjects1[i].setColor("255;255;255");
}
}
{ //Subevents
gdjs.DeskPromptCode.eventsList0(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Next"), gdjs.DeskPromptCode.GDNextObjects1);

gdjs.DeskPromptCode.condition0IsTrue_0.val = false;
{
gdjs.DeskPromptCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.DeskPromptCode.mapOfGDgdjs_46DeskPromptCode_46GDNextObjects1Objects, runtimeScene, true, true);
}if (gdjs.DeskPromptCode.condition0IsTrue_0.val) {
/* Reuse gdjs.DeskPromptCode.GDNextObjects1 */
{for(var i = 0, len = gdjs.DeskPromptCode.GDNextObjects1.length ;i < len;++i) {
    gdjs.DeskPromptCode.GDNextObjects1[i].setColor("155;155;155");
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("successDialogue"), gdjs.DeskPromptCode.GDsuccessDialogueObjects1);

gdjs.DeskPromptCode.condition0IsTrue_0.val = false;
gdjs.DeskPromptCode.condition1IsTrue_0.val = false;
{
gdjs.DeskPromptCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if ( gdjs.DeskPromptCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.DeskPromptCode.GDsuccessDialogueObjects1.length;i<l;++i) {
    if ( !(gdjs.DeskPromptCode.GDsuccessDialogueObjects1[i].isVisible()) ) {
        gdjs.DeskPromptCode.condition1IsTrue_0.val = true;
        gdjs.DeskPromptCode.GDsuccessDialogueObjects1[k] = gdjs.DeskPromptCode.GDsuccessDialogueObjects1[i];
        ++k;
    }
}
gdjs.DeskPromptCode.GDsuccessDialogueObjects1.length = k;}}
if (gdjs.DeskPromptCode.condition1IsTrue_0.val) {

{ //Subevents
gdjs.DeskPromptCode.eventsList1(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("CONFIRM"), gdjs.DeskPromptCode.GDCONFIRMObjects1);

gdjs.DeskPromptCode.condition0IsTrue_0.val = false;
{
gdjs.DeskPromptCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.DeskPromptCode.mapOfGDgdjs_46DeskPromptCode_46GDCONFIRMObjects1Objects, runtimeScene, true, false);
}if (gdjs.DeskPromptCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.DeskPromptCode.eventsList2(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("helpButton"), gdjs.DeskPromptCode.GDhelpButtonObjects1);
gdjs.copyArray(runtimeScene.getObjects("helpDialogue"), gdjs.DeskPromptCode.GDhelpDialogueObjects1);

gdjs.DeskPromptCode.condition0IsTrue_0.val = false;
gdjs.DeskPromptCode.condition1IsTrue_0.val = false;
{
gdjs.DeskPromptCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.DeskPromptCode.mapOfGDgdjs_46DeskPromptCode_46GDhelpButtonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.DeskPromptCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.DeskPromptCode.GDhelpDialogueObjects1.length;i<l;++i) {
    if ( gdjs.DeskPromptCode.GDhelpDialogueObjects1[i].isVisible() ) {
        gdjs.DeskPromptCode.condition1IsTrue_0.val = true;
        gdjs.DeskPromptCode.GDhelpDialogueObjects1[k] = gdjs.DeskPromptCode.GDhelpDialogueObjects1[i];
        ++k;
    }
}
gdjs.DeskPromptCode.GDhelpDialogueObjects1.length = k;}}
if (gdjs.DeskPromptCode.condition1IsTrue_0.val) {

{ //Subevents
gdjs.DeskPromptCode.eventsList3(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("helpButton"), gdjs.DeskPromptCode.GDhelpButtonObjects1);
gdjs.copyArray(runtimeScene.getObjects("helpDialogue"), gdjs.DeskPromptCode.GDhelpDialogueObjects1);
gdjs.copyArray(runtimeScene.getObjects("successDialogue"), gdjs.DeskPromptCode.GDsuccessDialogueObjects1);

gdjs.DeskPromptCode.condition0IsTrue_0.val = false;
gdjs.DeskPromptCode.condition1IsTrue_0.val = false;
gdjs.DeskPromptCode.condition2IsTrue_0.val = false;
{
gdjs.DeskPromptCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.DeskPromptCode.mapOfGDgdjs_46DeskPromptCode_46GDhelpButtonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.DeskPromptCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.DeskPromptCode.GDhelpDialogueObjects1.length;i<l;++i) {
    if ( !(gdjs.DeskPromptCode.GDhelpDialogueObjects1[i].isVisible()) ) {
        gdjs.DeskPromptCode.condition1IsTrue_0.val = true;
        gdjs.DeskPromptCode.GDhelpDialogueObjects1[k] = gdjs.DeskPromptCode.GDhelpDialogueObjects1[i];
        ++k;
    }
}
gdjs.DeskPromptCode.GDhelpDialogueObjects1.length = k;}if ( gdjs.DeskPromptCode.condition1IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.DeskPromptCode.GDsuccessDialogueObjects1.length;i<l;++i) {
    if ( !(gdjs.DeskPromptCode.GDsuccessDialogueObjects1[i].isVisible()) ) {
        gdjs.DeskPromptCode.condition2IsTrue_0.val = true;
        gdjs.DeskPromptCode.GDsuccessDialogueObjects1[k] = gdjs.DeskPromptCode.GDsuccessDialogueObjects1[i];
        ++k;
    }
}
gdjs.DeskPromptCode.GDsuccessDialogueObjects1.length = k;}}
}
if (gdjs.DeskPromptCode.condition2IsTrue_0.val) {

{ //Subevents
gdjs.DeskPromptCode.eventsList4(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("CONFIRM"), gdjs.DeskPromptCode.GDCONFIRMObjects1);

gdjs.DeskPromptCode.condition0IsTrue_0.val = false;
{
gdjs.DeskPromptCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.DeskPromptCode.mapOfGDgdjs_46DeskPromptCode_46GDCONFIRMObjects1Objects, runtimeScene, true, false);
}if (gdjs.DeskPromptCode.condition0IsTrue_0.val) {
/* Reuse gdjs.DeskPromptCode.GDCONFIRMObjects1 */
{for(var i = 0, len = gdjs.DeskPromptCode.GDCONFIRMObjects1.length ;i < len;++i) {
    gdjs.DeskPromptCode.GDCONFIRMObjects1[i].setColor("255;255;255");
}
}
{ //Subevents
gdjs.DeskPromptCode.eventsList5(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("CONFIRM"), gdjs.DeskPromptCode.GDCONFIRMObjects1);

gdjs.DeskPromptCode.condition0IsTrue_0.val = false;
{
gdjs.DeskPromptCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.DeskPromptCode.mapOfGDgdjs_46DeskPromptCode_46GDCONFIRMObjects1Objects, runtimeScene, true, true);
}if (gdjs.DeskPromptCode.condition0IsTrue_0.val) {
/* Reuse gdjs.DeskPromptCode.GDCONFIRMObjects1 */
{for(var i = 0, len = gdjs.DeskPromptCode.GDCONFIRMObjects1.length ;i < len;++i) {
    gdjs.DeskPromptCode.GDCONFIRMObjects1[i].setColor("155;155;155");
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("exitButton"), gdjs.DeskPromptCode.GDexitButtonObjects1);
gdjs.copyArray(runtimeScene.getObjects("exitDialogue"), gdjs.DeskPromptCode.GDexitDialogueObjects1);

gdjs.DeskPromptCode.condition0IsTrue_0.val = false;
gdjs.DeskPromptCode.condition1IsTrue_0.val = false;
{
gdjs.DeskPromptCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.DeskPromptCode.mapOfGDgdjs_46DeskPromptCode_46GDexitButtonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.DeskPromptCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.DeskPromptCode.GDexitDialogueObjects1.length;i<l;++i) {
    if ( gdjs.DeskPromptCode.GDexitDialogueObjects1[i].isVisible() ) {
        gdjs.DeskPromptCode.condition1IsTrue_0.val = true;
        gdjs.DeskPromptCode.GDexitDialogueObjects1[k] = gdjs.DeskPromptCode.GDexitDialogueObjects1[i];
        ++k;
    }
}
gdjs.DeskPromptCode.GDexitDialogueObjects1.length = k;}}
if (gdjs.DeskPromptCode.condition1IsTrue_0.val) {

{ //Subevents
gdjs.DeskPromptCode.eventsList6(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("exitButton"), gdjs.DeskPromptCode.GDexitButtonObjects1);
gdjs.copyArray(runtimeScene.getObjects("exitDialogue"), gdjs.DeskPromptCode.GDexitDialogueObjects1);
gdjs.copyArray(runtimeScene.getObjects("successDialogue"), gdjs.DeskPromptCode.GDsuccessDialogueObjects1);

gdjs.DeskPromptCode.condition0IsTrue_0.val = false;
gdjs.DeskPromptCode.condition1IsTrue_0.val = false;
gdjs.DeskPromptCode.condition2IsTrue_0.val = false;
{
gdjs.DeskPromptCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.DeskPromptCode.mapOfGDgdjs_46DeskPromptCode_46GDexitButtonObjects1Objects, runtimeScene, true, false);
}if ( gdjs.DeskPromptCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.DeskPromptCode.GDexitDialogueObjects1.length;i<l;++i) {
    if ( !(gdjs.DeskPromptCode.GDexitDialogueObjects1[i].isVisible()) ) {
        gdjs.DeskPromptCode.condition1IsTrue_0.val = true;
        gdjs.DeskPromptCode.GDexitDialogueObjects1[k] = gdjs.DeskPromptCode.GDexitDialogueObjects1[i];
        ++k;
    }
}
gdjs.DeskPromptCode.GDexitDialogueObjects1.length = k;}if ( gdjs.DeskPromptCode.condition1IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.DeskPromptCode.GDsuccessDialogueObjects1.length;i<l;++i) {
    if ( !(gdjs.DeskPromptCode.GDsuccessDialogueObjects1[i].isVisible()) ) {
        gdjs.DeskPromptCode.condition2IsTrue_0.val = true;
        gdjs.DeskPromptCode.GDsuccessDialogueObjects1[k] = gdjs.DeskPromptCode.GDsuccessDialogueObjects1[i];
        ++k;
    }
}
gdjs.DeskPromptCode.GDsuccessDialogueObjects1.length = k;}}
}
if (gdjs.DeskPromptCode.condition2IsTrue_0.val) {

{ //Subevents
gdjs.DeskPromptCode.eventsList7(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("YES"), gdjs.DeskPromptCode.GDYESObjects1);

gdjs.DeskPromptCode.condition0IsTrue_0.val = false;
{
gdjs.DeskPromptCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.DeskPromptCode.mapOfGDgdjs_46DeskPromptCode_46GDYESObjects1Objects, runtimeScene, true, false);
}if (gdjs.DeskPromptCode.condition0IsTrue_0.val) {
/* Reuse gdjs.DeskPromptCode.GDYESObjects1 */
{for(var i = 0, len = gdjs.DeskPromptCode.GDYESObjects1.length ;i < len;++i) {
    gdjs.DeskPromptCode.GDYESObjects1[i].setColor("255;255;255");
}
}
{ //Subevents
gdjs.DeskPromptCode.eventsList8(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("NO"), gdjs.DeskPromptCode.GDNOObjects1);

gdjs.DeskPromptCode.condition0IsTrue_0.val = false;
{
gdjs.DeskPromptCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.DeskPromptCode.mapOfGDgdjs_46DeskPromptCode_46GDNOObjects1Objects, runtimeScene, true, false);
}if (gdjs.DeskPromptCode.condition0IsTrue_0.val) {
/* Reuse gdjs.DeskPromptCode.GDNOObjects1 */
{for(var i = 0, len = gdjs.DeskPromptCode.GDNOObjects1.length ;i < len;++i) {
    gdjs.DeskPromptCode.GDNOObjects1[i].setColor("255;255;255");
}
}
{ //Subevents
gdjs.DeskPromptCode.eventsList9(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("YES"), gdjs.DeskPromptCode.GDYESObjects1);

gdjs.DeskPromptCode.condition0IsTrue_0.val = false;
{
gdjs.DeskPromptCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.DeskPromptCode.mapOfGDgdjs_46DeskPromptCode_46GDYESObjects1Objects, runtimeScene, true, true);
}if (gdjs.DeskPromptCode.condition0IsTrue_0.val) {
/* Reuse gdjs.DeskPromptCode.GDYESObjects1 */
{for(var i = 0, len = gdjs.DeskPromptCode.GDYESObjects1.length ;i < len;++i) {
    gdjs.DeskPromptCode.GDYESObjects1[i].setColor("155;155;155");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("NO"), gdjs.DeskPromptCode.GDNOObjects1);

gdjs.DeskPromptCode.condition0IsTrue_0.val = false;
{
gdjs.DeskPromptCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.DeskPromptCode.mapOfGDgdjs_46DeskPromptCode_46GDNOObjects1Objects, runtimeScene, true, true);
}if (gdjs.DeskPromptCode.condition0IsTrue_0.val) {
/* Reuse gdjs.DeskPromptCode.GDNOObjects1 */
{for(var i = 0, len = gdjs.DeskPromptCode.GDNOObjects1.length ;i < len;++i) {
    gdjs.DeskPromptCode.GDNOObjects1[i].setColor("155;155;155");
}
}}

}


{


gdjs.DeskPromptCode.eventsList11(runtimeScene);
}


};

gdjs.DeskPromptCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.DeskPromptCode.GDBackgroundObjects1.length = 0;
gdjs.DeskPromptCode.GDBackgroundObjects2.length = 0;
gdjs.DeskPromptCode.GDBackgroundObjects3.length = 0;
gdjs.DeskPromptCode.GDCodePromptObjects1.length = 0;
gdjs.DeskPromptCode.GDCodePromptObjects2.length = 0;
gdjs.DeskPromptCode.GDCodePromptObjects3.length = 0;
gdjs.DeskPromptCode.GDInstructionsObjects1.length = 0;
gdjs.DeskPromptCode.GDInstructionsObjects2.length = 0;
gdjs.DeskPromptCode.GDInstructionsObjects3.length = 0;
gdjs.DeskPromptCode.GDforObjects1.length = 0;
gdjs.DeskPromptCode.GDforObjects2.length = 0;
gdjs.DeskPromptCode.GDforObjects3.length = 0;
gdjs.DeskPromptCode.GDifObjects1.length = 0;
gdjs.DeskPromptCode.GDifObjects2.length = 0;
gdjs.DeskPromptCode.GDifObjects3.length = 0;
gdjs.DeskPromptCode.GDbodyObjects1.length = 0;
gdjs.DeskPromptCode.GDbodyObjects2.length = 0;
gdjs.DeskPromptCode.GDbodyObjects3.length = 0;
gdjs.DeskPromptCode.GDpieceStartObjects1.length = 0;
gdjs.DeskPromptCode.GDpieceStartObjects2.length = 0;
gdjs.DeskPromptCode.GDpieceStartObjects3.length = 0;
gdjs.DeskPromptCode.GDpieceEndObjects1.length = 0;
gdjs.DeskPromptCode.GDpieceEndObjects2.length = 0;
gdjs.DeskPromptCode.GDpieceEndObjects3.length = 0;
gdjs.DeskPromptCode.GDpieceClueObjects1.length = 0;
gdjs.DeskPromptCode.GDpieceClueObjects2.length = 0;
gdjs.DeskPromptCode.GDpieceClueObjects3.length = 0;
gdjs.DeskPromptCode.GDpieceBreakObjects1.length = 0;
gdjs.DeskPromptCode.GDpieceBreakObjects2.length = 0;
gdjs.DeskPromptCode.GDpieceBreakObjects3.length = 0;
gdjs.DeskPromptCode.GDbox1Objects1.length = 0;
gdjs.DeskPromptCode.GDbox1Objects2.length = 0;
gdjs.DeskPromptCode.GDbox1Objects3.length = 0;
gdjs.DeskPromptCode.GDbox2Objects1.length = 0;
gdjs.DeskPromptCode.GDbox2Objects2.length = 0;
gdjs.DeskPromptCode.GDbox2Objects3.length = 0;
gdjs.DeskPromptCode.GDbox3Objects1.length = 0;
gdjs.DeskPromptCode.GDbox3Objects2.length = 0;
gdjs.DeskPromptCode.GDbox3Objects3.length = 0;
gdjs.DeskPromptCode.GDbox4Objects1.length = 0;
gdjs.DeskPromptCode.GDbox4Objects2.length = 0;
gdjs.DeskPromptCode.GDbox4Objects3.length = 0;
gdjs.DeskPromptCode.GDSuccessObjects1.length = 0;
gdjs.DeskPromptCode.GDSuccessObjects2.length = 0;
gdjs.DeskPromptCode.GDSuccessObjects3.length = 0;
gdjs.DeskPromptCode.GDDialogueBoxObjects1.length = 0;
gdjs.DeskPromptCode.GDDialogueBoxObjects2.length = 0;
gdjs.DeskPromptCode.GDDialogueBoxObjects3.length = 0;
gdjs.DeskPromptCode.GDhelpDialogueObjects1.length = 0;
gdjs.DeskPromptCode.GDhelpDialogueObjects2.length = 0;
gdjs.DeskPromptCode.GDhelpDialogueObjects3.length = 0;
gdjs.DeskPromptCode.GDexitButtonObjects1.length = 0;
gdjs.DeskPromptCode.GDexitButtonObjects2.length = 0;
gdjs.DeskPromptCode.GDexitButtonObjects3.length = 0;
gdjs.DeskPromptCode.GDhelpButtonObjects1.length = 0;
gdjs.DeskPromptCode.GDhelpButtonObjects2.length = 0;
gdjs.DeskPromptCode.GDhelpButtonObjects3.length = 0;
gdjs.DeskPromptCode.GDexitDialogueObjects1.length = 0;
gdjs.DeskPromptCode.GDexitDialogueObjects2.length = 0;
gdjs.DeskPromptCode.GDexitDialogueObjects3.length = 0;
gdjs.DeskPromptCode.GDYESObjects1.length = 0;
gdjs.DeskPromptCode.GDYESObjects2.length = 0;
gdjs.DeskPromptCode.GDYESObjects3.length = 0;
gdjs.DeskPromptCode.GDNOObjects1.length = 0;
gdjs.DeskPromptCode.GDNOObjects2.length = 0;
gdjs.DeskPromptCode.GDNOObjects3.length = 0;
gdjs.DeskPromptCode.GDCONFIRMObjects1.length = 0;
gdjs.DeskPromptCode.GDCONFIRMObjects2.length = 0;
gdjs.DeskPromptCode.GDCONFIRMObjects3.length = 0;
gdjs.DeskPromptCode.GDDialogueObjects1.length = 0;
gdjs.DeskPromptCode.GDDialogueObjects2.length = 0;
gdjs.DeskPromptCode.GDDialogueObjects3.length = 0;
gdjs.DeskPromptCode.GDNextObjects1.length = 0;
gdjs.DeskPromptCode.GDNextObjects2.length = 0;
gdjs.DeskPromptCode.GDNextObjects3.length = 0;
gdjs.DeskPromptCode.GDsuccessDialogueObjects1.length = 0;
gdjs.DeskPromptCode.GDsuccessDialogueObjects2.length = 0;
gdjs.DeskPromptCode.GDsuccessDialogueObjects3.length = 0;
gdjs.DeskPromptCode.GDTimerSecondsObjects1.length = 0;
gdjs.DeskPromptCode.GDTimerSecondsObjects2.length = 0;
gdjs.DeskPromptCode.GDTimerSecondsObjects3.length = 0;
gdjs.DeskPromptCode.GDTimerMinutesObjects1.length = 0;
gdjs.DeskPromptCode.GDTimerMinutesObjects2.length = 0;
gdjs.DeskPromptCode.GDTimerMinutesObjects3.length = 0;

gdjs.DeskPromptCode.eventsList12(runtimeScene);
return;

}

gdjs['DeskPromptCode'] = gdjs.DeskPromptCode;
